#!/usr/bin/env bash
# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

set -euo pipefail

KLEM_VERSION="0.5.3"
KLEM_SHA256="a9c3f824377433cc38b25f239d6f8bb5b5e746e4a2b0159c19fad698e827ce38"
TMP_DIR=""
BASE_URL="${KLEM_BASE_URL:-https://osaif.pages.dev/klem-files}"

main() {
    local tarball="klem-${KLEM_VERSION}.tar.gz"
    local rc=0 sums="" stdin_src

    say()  { printf '\033[1;32m==>\033[0m %s\n' "$*"; }
    die()  { printf '\033[1;31mError:\033[0m %s\n' "$*" >&2; exit 1; }

    [ "$(uname -s)" = "Linux" ] || die "Klem only runs on Linux."
    [ "$(id -u)" -ne 0 ] || die "Don't run this as root or with sudo."
    for tool in curl tar mktemp; do
        command -v "$tool" >/dev/null 2>&1 || die "'$tool' is required but not installed."
    done

    TMP_DIR="$(mktemp -d)"
    trap '[ -z "$TMP_DIR" ] || rm -rf "$TMP_DIR"' EXIT

    say "Downloading Klem ${KLEM_VERSION}..."
    curl -fSL --retry 3 --connect-timeout 20 -o "$TMP_DIR/$tarball" \
        "$BASE_URL/$KLEM_VERSION/$tarball" \
        || die "Download failed ($BASE_URL/$KLEM_VERSION/$tarball)."

    if command -v sha256sum >/dev/null 2>&1; then
        sums="$(sha256sum "$TMP_DIR/$tarball")"
    elif command -v shasum >/dev/null 2>&1; then
        sums="$(shasum -a 256 "$TMP_DIR/$tarball")"
    else
        die "'sha256sum' or 'shasum' is required."
    fi
    [ "${sums%% *}" = "$KLEM_SHA256" ] \
        || die "Checksum mismatch."

    tar -xzf "$TMP_DIR/$tarball" -C "$TMP_DIR" || die "Couldn't unpack the download."
    [ -f "$TMP_DIR/klem-$KLEM_VERSION/install.sh" ] || die "The download doesn't contain the installer."

    if ( : </dev/tty ) 2>/dev/null; then stdin_src=/dev/tty; else stdin_src=/dev/null; fi

    if bash "$TMP_DIR/klem-$KLEM_VERSION/install.sh" "$@" <"$stdin_src"; then
        rc=0
    else
        rc=$?
    fi
    return "$rc"
}

main "$@"
