# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import threading
from collections import deque
from typing import Deque, List, Optional

from PyQt6.QtCore import QThread, pyqtSignal

from .env import ToolMissing, find_tool, install_hint

SPEED_PRESETS = {
    "Fast":     "veryfast",
    "Balanced": "medium",
    "Smaller":  "slow",
}

_CPU_USED = {
    "ultrafast": 8, "superfast": 7, "veryfast": 6, "faster": 5, "fast": 4,
    "medium": 3, "slow": 2, "slower": 1, "veryslow": 0,
}

_CRF_RANGE = {
    "libx264":    (18, 35, 51),
    "libx265":    (20, 38, 51),
    "libvpx-vp9": (24, 45, 63),
    "libvpx":     (8, 30, 63),
    "libaom-av1": (24, 45, 63),
}
DEFAULT_CRF = {"libx264": 23, "libx265": 28, "libvpx-vp9": 33, "libvpx": 10, "libaom-av1": 32}
CRF_MIN = {"libvpx": 4}

_HEIGHTS = {"4k": 2160, "1440p": 1440, "1080p": 1080, "720p": 720, "480p": 480, "360p": 360}

AUDIO_CODEC_EXT = {
    "libmp3lame": ".mp3", "aac": ".m4a", "libopus": ".opus", "flac": ".flac",
    "pcm_s16le": ".wav", "libvorbis": ".ogg", "ac3": ".ac3",
}
_COPY_EXT = {
    "aac": ".m4a", "mp3": ".mp3", "opus": ".opus", "vorbis": ".ogg",
    "flac": ".flac", "ac3": ".ac3", "eac3": ".eac3", "alac": ".m4a",
}
_WEBM_AUDIO = {"libopus", "libvorbis"}
_MP4_NO_COPY = {"vorbis", "truehd", "mlp", "wmav1", "wmav2", "wmapro", "wmalossless",
                "adpcm_ima_wav", "adpcm_ms"}
_MOV_NO_COPY = _MP4_NO_COPY | {"opus", "flac"}
_VORBIS_KBPS = {
    8000:  (8, 42, 12, 84),    11025: (12, 50, 16, 100), 16000: (16, 100, 24, 200),
    22050: (16, 90, 30, 180),  24000: (16, 90, 30, 180), 32000: (30, 190, 36, 380),
    44100: (32, 240, 45, 500), 48000: (32, 240, 45, 500),
}
_VORBIS_SURROUND = {
    3: {8000: (24, 126), 11025: (36, 150), 16000: (48, 300), 22050: (48, 270),
        24000: (48, 270), 32000: (90, 570), 44100: (96, 640), 48000: (96, 640)},
    4: {8000: (32, 168), 11025: (48, 200), 16000: (64, 400), 22050: (64, 360),
        24000: (64, 360), 32000: (120, 640), 44100: (128, 640), 48000: (128, 640)},
    5: {8000: (40, 210), 11025: (60, 250), 16000: (80, 500), 22050: (80, 450),
        24000: (80, 450), 32000: (150, 640), 44100: (160, 640), 48000: (160, 640)},
    6: {8000: (48, 252), 11025: (72, 300), 16000: (96, 600), 22050: (96, 540),
        24000: (96, 540), 32000: (180, 640), 44100: (84, 640), 48000: (84, 640)},
}
_VORBIS_WINDOWS = dict(_VORBIS_SURROUND)
_VORBIS_WINDOWS[1] = {r: (v[0], v[1]) for r, v in _VORBIS_KBPS.items()}
_VORBIS_WINDOWS[2] = {r: (v[2], v[3]) for r, v in _VORBIS_KBPS.items()}
_OPUS_RATES = {"8000", "12000", "16000", "24000", "48000"}
_AC3_RATES = {"32000", "44100", "48000"}
_OPUS_LAYOUT = {3: "3.0", 4: "quad", 5: "5.0", 6: "5.1", 7: "6.1", 8: "7.1"}


def quality_to_crf(quality: int, codec: str = "libx264") -> int:
    best, worst, _ = _CRF_RANGE.get(codec, _CRF_RANGE["libx264"])
    quality = max(0, min(100, int(quality)))
    return int(round(worst + (best - worst) * quality / 100.0))


def _ffmpeg() -> str:
    path = find_tool("ffmpeg")
    if not path:
        raise ToolMissing("ffmpeg not found — %s" % install_hint("ffmpeg"))
    return path


def _ext(path: str) -> str:
    return os.path.splitext(path)[1].lower()


def _fmt_kbps(value) -> str:
    return "%dk" % int(value)


def _to_int(value) -> Optional[int]:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _surround_layout(acodec: str, channels: Optional[int]) -> str:
    if not channels or channels <= 2:
        return ""
    if acodec == "libopus":
        return _OPUS_LAYOUT.get(channels, "")
    if acodec == "libvorbis" and channels > 6:
        return "5.1"
    return ""


def build_command(s: dict) -> List[str]:
    if s.get("audio_only"):
        return build_audio_command(s)

    codec = s.get("codec", "libx264")
    out = s["output"]
    out_ext = _ext(out)
    cmd = [_ffmpeg(), "-hide_banner", "-nostdin", "-y", "-i", s["input"]]

    filters: List[str] = []
    pix_fmt = s.get("pix_fmt", "yuv420p")
    if codec == "libvpx":
        pix_fmt = "yuv420p"
    res = s.get("resolution", "original")
    if res in _HEIGHTS:
        filters.append("scale=-2:trunc(min(ih\\,%d)/2)*2" % _HEIGHTS[res])
    else:
        size = s.get("source_size")
        if size and (size[0] % 2 or size[1] % 2):
            filters.append("scale=trunc(iw/2)*2:trunc(ih/2)*2")
    if s.get("denoise"):
        filters.append("hqdn3d")

    cmd += ["-map", "0:v:0"]
    if filters:
        cmd += ["-vf", ",".join(filters)]
    fps = s.get("fps")
    if fps and fps != "original":
        cmd += ["-r", str(fps)]

    cmd += ["-c:v", codec]
    bitrate = s.get("video_bitrate")
    if bitrate:
        cmd += ["-b:v", _fmt_kbps(bitrate)]
    else:
        crf = s.get("crf")
        _, _, crf_max = _CRF_RANGE.get(codec, _CRF_RANGE["libx264"])
        if crf is None:
            crf = quality_to_crf(s.get("quality", 60), codec)
        crf = max(CRF_MIN.get(codec, 0), min(crf_max, int(crf)))
        cmd += ["-crf", str(crf)]
        if codec == "libvpx":
            cmd += ["-b:v", "10M"]
        elif codec in ("libvpx-vp9", "libaom-av1"):
            cmd += ["-b:v", "0"]

    preset = s.get("preset", "medium")
    if codec in ("libx264", "libx265"):
        cmd += ["-preset", preset]
        tune = s.get("tune")
        if tune and not (codec == "libx265" and tune in ("film", "stillimage")):
            cmd += ["-tune", tune]
        profile = s.get("profile")
        if codec == "libx264" and profile and pix_fmt == "yuv420p":
            cmd += ["-profile:v", profile]
    elif codec == "libvpx-vp9":
        cmd += ["-cpu-used", str(_CPU_USED.get(preset, 3)), "-row-mt", "1"]
    elif codec in ("libvpx", "libaom-av1"):
        cmd += ["-cpu-used", str(_CPU_USED.get(preset, 3))]
    if codec == "libaom-av1":
        cmd += ["-row-mt", "1"]
    if pix_fmt:
        cmd += ["-pix_fmt", pix_fmt]
    if codec == "libx265" and out_ext in (".mp4", ".m4v", ".mov"):
        cmd += ["-tag:v", "hvc1"]

    mode = s.get("audio_mode", "transcode")
    if mode == "none":
        cmd += ["-an"]
    else:
        cmd += ["-map", "0:a:0?"]
        if mode == "copy" and _can_copy_audio(s, out_ext):
            cmd += ["-c:a", "copy"]
        elif mode == "copy":
            cmd += _audio_encode_args(dict(s, audio_codec="copy"), out_ext)
        else:
            cmd += _audio_encode_args(s, out_ext)

    if s.get("strip_metadata"):
        cmd += ["-map_metadata", "-1"]
    if s.get("strip_chapters") or s.get("strip_metadata"):
        cmd += ["-map_chapters", "-1"]

    cmd += _custom_args(s)
    cmd.append(out)
    return cmd


def _can_copy_audio(s: dict, out_ext: str) -> bool:
    src = (s.get("source_audio_codec") or "").lower()
    if out_ext == ".webm":
        return src in ("opus", "vorbis")
    if out_ext == ".m4v":
        return src in ("aac", "alac", "ac3")
    if out_ext == ".mp4":
        return src not in _MP4_NO_COPY
    if out_ext == ".mov":
        return src not in _MOV_NO_COPY
    return True


def _clamp_vorbis_kbps(bitrate, channels, rate) -> int:
    bitrate = int(bitrate)
    try:
        channels, rate = int(channels), int(rate)
    except (TypeError, ValueError):
        return bitrate
    channels = min(channels, 6)
    windows = _VORBIS_WINDOWS.get(channels)
    if windows is None or not 8000 <= rate <= 48000:
        return bitrate
    lower = windows[max(r for r in windows if r <= rate)]
    upper = windows[min(r for r in windows if r >= rate)]
    low, high = max(lower[0], upper[0]), min(lower[1], upper[1])
    return max(low, min(high, bitrate))


def _audio_encode_args(s: dict, out_ext: str) -> List[str]:
    acodec = s.get("audio_codec") or "aac"
    if acodec == "copy" and not s.get("audio_only") and not _can_copy_audio(s, out_ext):
        acodec = "aac"
    if out_ext == ".webm" and acodec not in _WEBM_AUDIO | {"copy"}:
        acodec = "libopus"
    elif out_ext == ".mov" and acodec in ("libopus", "flac"):
        acodec = "aac"
    elif out_ext == ".m4v" and acodec not in ("aac", "ac3", "copy"):
        acodec = "aac"
    args = ["-c:a", acodec]
    if acodec == "copy":
        return args
    channels = s.get("audio_channels")
    rate = s.get("audio_sample_rate")
    if rate == "original":
        rate = None
    src_rate = _to_int(s.get("source_sample_rate"))
    if not rate and src_rate:
        if acodec == "libvorbis" and src_rate > 48000:
            rate = "48000"
        elif acodec == "libvorbis" and src_rate < 8000:
            rate = "8000"
        elif acodec == "libmp3lame" and out_ext == ".mp4" and src_rate < 16000:
            rate = "16000"
    bitrate = s.get("audio_bitrate")
    if bitrate and acodec not in ("flac", "pcm_s16le"):
        out_channels = channels or s.get("source_channels")
        if acodec == "libmp3lame":
            bitrate = min(int(bitrate), 320)
        elif acodec == "libopus":
            bitrate = min(int(bitrate), 256 * int(out_channels or 2))
        elif acodec == "libvorbis":
            bitrate = _clamp_vorbis_kbps(bitrate, out_channels, rate or s.get("source_sample_rate"))
        elif acodec == "ac3" and (_to_int(out_channels) or 2) >= 4:
            bitrate = max(int(bitrate), 64)
        args += ["-b:a", _fmt_kbps(bitrate)]
    if channels:
        args += ["-ac", str(channels)]
    else:
        layout = _surround_layout(acodec, _to_int(s.get("source_channels")))
        if layout:
            args += ["-af", "aformat=channel_layouts=" + layout]
    if rate:
        rate = str(rate)
        if (acodec == "libopus" and rate not in _OPUS_RATES) or \
                (acodec == "ac3" and rate not in _AC3_RATES):
            rate = "48000"
        args += ["-ar", rate]
    return args


def build_audio_command(s: dict) -> List[str]:
    cmd = [_ffmpeg(), "-hide_banner", "-nostdin", "-y", "-i", s["input"],
           "-vn", "-map", "0:a:0"]
    cmd += _audio_encode_args(s, _ext(s["output"]))
    if s.get("strip_metadata"):
        cmd += ["-map_metadata", "-1"]
    if s.get("strip_chapters") or s.get("strip_metadata"):
        cmd += ["-map_chapters", "-1"]
    cmd += _custom_args(s)
    cmd.append(s["output"])
    return cmd


def _custom_args(s: dict) -> List[str]:
    extra = (s.get("custom_args") or "").strip()
    if not extra:
        return []
    try:
        return shlex.split(extra)
    except ValueError as exc:
        raise ValueError("extra flags: %s" % exc)


_NO_VALUE_FLAGS = {"-y", "-nostdin", "-hide_banner", "-an", "-vn"}
_FLAG_RE = re.compile(r"^-[A-Za-z]")


def format_command_str(cmd: List[str]) -> str:
    parts = [os.path.basename(cmd[0])]
    last = len(cmd) - 1
    i = 1
    while i < len(cmd):
        token = cmd[i]
        takes_value = (_FLAG_RE.match(token) and token not in _NO_VALUE_FLAGS
                       and i + 1 < last and not _FLAG_RE.match(cmd[i + 1]))
        if takes_value:
            parts.append("%s %s" % (shlex.quote(token), shlex.quote(cmd[i + 1])))
            i += 2
        else:
            parts.append(shlex.quote(token))
            i += 1
    return " \\\n  ".join(parts)


def suggest_output_path(input_path: str, codec: str, audio_only: bool = False,
                        source_audio_codec: Optional[str] = None) -> str:
    base, _ = os.path.splitext(input_path)
    if audio_only:
        if codec == "copy":
            ext = _COPY_EXT.get((source_audio_codec or "").lower(), ".mka")
        else:
            ext = AUDIO_CODEC_EXT.get(codec, ".m4a")
        stem = base
    else:
        ext = ".webm" if codec in ("libvpx", "libvpx-vp9", "libaom-av1") else ".mp4"
        stem = base + "_compressed"
    candidate = stem + ext
    n = 2
    while os.path.exists(candidate) or candidate == input_path:
        candidate = "%s_%d%s" % (stem, n, ext)
        n += 1
    return candidate


def fmt_size(num: float) -> str:
    num = float(num)
    for unit in ("B", "KB", "MB", "GB"):
        if num < 1024 or unit == "GB":
            return ("%.0f %s" % (num, unit)) if unit == "B" else ("%.1f %s" % (num, unit))
        num /= 1024.0
    return "%.1f GB" % num


def fmt_duration(seconds: float) -> str:
    seconds = int(round(seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


def probe_video(path: str) -> dict:
    ffprobe = find_tool("ffprobe")
    if not ffprobe:
        raise ToolMissing("ffprobe not found — %s" % install_hint("ffmpeg"))
    try:
        proc = subprocess.run(
            [ffprobe, "-v", "error", "-print_format", "json", "-show_format", "-show_streams", path],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL, timeout=60,
            universal_newlines=True, encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired:
        raise RuntimeError("reading the file took too long")
    if proc.returncode != 0:
        detail = proc.stderr.strip().splitlines()
        raise RuntimeError(detail[-1] if detail else "not a readable media file")
    try:
        data = json.loads(proc.stdout or "{}")
    except ValueError:
        raise RuntimeError("ffprobe returned unreadable output")

    streams = data.get("streams", [])
    fmt = data.get("format", {})
    video = next((st for st in streams if st.get("codec_type") == "video"
                  and not (st.get("disposition") or {}).get("attached_pic")), None)
    audio = next((st for st in streams if st.get("codec_type") == "audio"), None)

    def to_float(value, default=0.0):
        try:
            return float(value)
        except (TypeError, ValueError):
            return default

    info = {
        "duration": to_float(fmt.get("duration")) or (to_float(video.get("duration")) if video else 0.0),
        "size": int(to_float(fmt.get("size")) or (os.path.getsize(path) if os.path.exists(path) else 0)),
        "video": None, "audio": None,
    }
    if video:
        fps = ""
        num, _, den = str(video.get("avg_frame_rate", "0/0")).partition("/")
        try:
            if int(den or 1) and int(num):
                fps = ("%.2f" % (int(num) / int(den))).rstrip("0").rstrip(".")
        except ValueError:
            pass
        info["video"] = {"codec": video.get("codec_name", ""), "width": video.get("width"),
                         "height": video.get("height"), "fps": fps}
    if audio:
        info["audio"] = {"codec": audio.get("codec_name", ""),
                         "channels": audio.get("channels"), "sample_rate": audio.get("sample_rate")}
    return info


_TIME_RE = re.compile(r"time=(\d+):(\d+):(\d+(?:\.\d+)?)")
_STATS_RE = re.compile(r"^(frame|size)=")
_SPEED_RE = re.compile(r"speed=\s*([\d.]+)x")


class FFmpegWorker(QThread):
    progress = pyqtSignal(int, str)
    done = pyqtSignal(bool, str)

    def __init__(self, cmd: List[str], duration: float, output: str, parent=None):
        super().__init__(parent)
        self._cmd = cmd
        self._duration = duration
        self._output = output
        self._proc: Optional[subprocess.Popen] = None
        self._cancelled = False
        self._lock = threading.Lock()

    def cancel(self):
        with self._lock:
            self._cancelled = True
            proc = self._proc
        if proc is not None and proc.poll() is None:
            try:
                proc.kill()
            except OSError:
                pass

    @property
    def cancelled(self) -> bool:
        return self._cancelled

    def run(self):
        tail: Deque[str] = deque(maxlen=30)
        try:
            with self._lock:
                if self._cancelled:
                    self.done.emit(False, "Cancelled")
                    return
                self._proc = subprocess.Popen(
                    self._cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE, universal_newlines=True, encoding="utf-8",
                    errors="replace", bufsize=1)
            proc = self._proc
            assert proc.stderr is not None
            last_pct = -1
            for line in proc.stderr:
                line = line.strip()
                if not line:
                    continue
                if _STATS_RE.match(line):
                    m = _TIME_RE.search(line)
                    if not m:
                        continue
                    if self._duration > 0:
                        elapsed = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
                        pct = max(0, min(99, int(elapsed / self._duration * 100)))
                    else:
                        pct = 0
                    sp = _SPEED_RE.search(line)
                    if pct != last_pct or self._duration <= 0:
                        last_pct = pct
                        self.progress.emit(pct, ("%sx speed" % sp.group(1)) if sp else "")
                else:
                    tail.append(line)
            code = proc.wait()
        except OSError as exc:
            self.done.emit(False, "Could not start ffmpeg: %s" % exc)
            return

        if self._cancelled:
            self._remove_partial()
            self.done.emit(False, "Cancelled")
        elif code == 0:
            self.done.emit(True, self._output)
        else:
            self._remove_partial()
            self.done.emit(False, _explain_failure(list(tail), code))

    def _remove_partial(self):
        try:
            if os.path.exists(self._output):
                os.remove(self._output)
        except OSError:
            pass


_CONTEXT_RE = re.compile(r"^\[[^\]]*\]\s*")
_REASON_RE = re.compile(
    r"\bonly\b.*\bsupported\b|not (?:currently )?supported|is not standard|Could not find tag|"
    r"Unable to |encoder setup failed|support is experimental|Invalid channel layout",
    re.IGNORECASE)
_NOISE_RE = re.compile(
    r"kb/s:|^\[lib\w+ @ [^\]]*\]\s*(?:frame [IPB]:|mb [IPB]|coded y|i16 v|i4 v|i8 v|i8c dc|"
    r"ref [PB]|consecutive B|weighted|PSNR|SSIM|encoded \d+ frames)|^x265 \[(?:info|warning)\]|"
    r"^Conversion failed!?$|Nothing was written into output file|^Error while filtering",
    re.IGNORECASE)


def _root_cause(tail: List[str]) -> str:
    for line in tail:
        plain = _CONTEXT_RE.sub("", line).strip()
        if plain and _REASON_RE.search(plain):
            return plain
    return ""


def _explain_failure(tail: List[str], code: int) -> str:
    text = "\n".join(tail)
    m = re.search(r"Unknown encoder '([^']+)'", text) or re.search(r"Encoder (\S+) not found", text)
    if m:
        return ("Your ffmpeg build has no '%s' encoder. Install a full ffmpeg build "
                "(on Fedora enable RPM Fusion) or pick another codec." % m.group(1))
    if "No space left" in text:
        return "The disk is full."
    if "Permission denied" in text:
        return "Permission denied writing the output file."
    m = re.search(r"Stream map '0:([av]):\d+' matches no streams", text)
    if m:
        return ("The input has no audio track." if m.group(1) == "a"
                else "The input has no video track.")
    if "does not contain any stream" in text:
        return "The input has no audio track to extract."
    cause = _root_cause(tail)
    if "Error while opening encoder" in text:
        return ("An encoder rejected these settings (check the bitrate, sample rate, size or "
                "codec)." + ((" ffmpeg said: " + cause)[:300] if cause else ""))
    if cause:
        return "ffmpeg failed: " + cause[:300]
    useful = [ln for ln in tail if not ln.startswith(("Stream mapping", "Press [q]", "Output #", "Input #",
                                                      "frame=", "size="))
              and not ln.lstrip().startswith(("Stream #", "Metadata", "encoder", "Duration"))
              and not _NOISE_RE.search(ln)]
    if useful:
        return "ffmpeg failed: " + " ".join(useful[-2:])[:300]
    return "ffmpeg exited with code %d" % code
