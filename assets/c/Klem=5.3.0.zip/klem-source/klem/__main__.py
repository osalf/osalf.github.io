# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import argparse
import os
import signal
import sys


_QT_VALUE_OPTIONS = {"-platform", "-platformpluginpath", "-platformtheme", "-style",
                     "-stylesheet", "-display", "-geometry", "-qmljsdebugger", "-session"}


def _parse(argv):
    parser = argparse.ArgumentParser(
        prog="klem", description="Klem - a clean, ffmpeg-powered video compressor.")
    parser.add_argument("file", nargs="?", help="a video to open right away")
    parser.add_argument("--no-splash", action="store_true", help="skip the splash screen")
    parser.add_argument("--version", action="store_true", help="print the version and exit")
    parser.add_argument("--install-ffmpeg", action="store_true",
                        help="download ffmpeg and ffprobe into your home folder and exit")
    qt_args, rest, i = [], [], 0
    while i < len(argv):
        if argv[i] == "--":
            rest += argv[i:]
            break
        if argv[i] in _QT_VALUE_OPTIONS and i + 1 < len(argv):
            qt_args += argv[i:i + 2]
            i += 2
        else:
            rest.append(argv[i])
            i += 1
    args, unknown = parser.parse_known_args(rest)
    return args, qt_args + unknown


def main():
    args, qt_args = _parse(sys.argv[1:])
    from . import __version__
    if args.version:
        print("klem " + __version__)
        return 0
    if args.install_ffmpeg:
        from .fetch import main as install_ffmpeg
        return install_ffmpeg()

    from PyQt6.QtWidgets import QApplication
    from .splash import SplashScreen

    signal.signal(signal.SIGINT, signal.SIG_DFL)
    app = QApplication([sys.argv[0]] + qt_args)
    app.setApplicationName("Klem")
    app.setApplicationVersion(__version__)
    app.setOrganizationName("ocaif")
    app.setDesktopFileName("klem")

    def launch():
        from .main_window import MainWindow
        window = MainWindow()
        app._main_window = window
        window.show()
        if args.file:
            window.open_path(os.path.abspath(args.file))

    if args.no_splash or os.environ.get("KLEM_NO_SPLASH"):
        launch()
    else:
        splash = SplashScreen()
        splash.done.connect(launch)
        splash.show_and_start()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
