# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

from typing import Optional

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QVBoxLayout, QWidget

from .core import suggest_output_path
from .widgets import DropZone, InfoBar, OutputField, section


class BaseView(QWidget):

    file_selected = pyqtSignal(str)
    message = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._input_path = ""
        self._info: Optional[dict] = None

        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(18, 18, 18, 18)
        self.root.setSpacing(12)

        self._drop = DropZone()
        self._drop.file_selected.connect(self._on_picked)
        self._drop.rejected.connect(self.message)
        self._info_bar = InfoBar()
        self._output = OutputField()

        self.root.addWidget(section("Video", self._drop, self._info_bar))
        self.root.addWidget(section("Output", self._output))

    def is_audio_only(self) -> bool:
        raise NotImplementedError

    def output_codec(self) -> str:
        raise NotImplementedError

    @property
    def input_path(self) -> str:
        return self._input_path

    def _on_picked(self, path: str):
        self._input_path = path
        self._info = None
        self._info_bar.hide()
        self._refresh_output(force=True)
        self.file_selected.emit(path)

    def set_input(self, path: str, info: Optional[dict]):
        changed = path != self._input_path
        self._input_path = path
        self._info = info
        self._drop.set_path(path)
        if info:
            self._info_bar.set_info(info)
        else:
            self._info_bar.hide()
        self._refresh_output(force=changed)
        self._on_info_changed()

    def _on_info_changed(self):
        pass

    def codec_combos(self):
        return []

    def refresh_encoders(self):
        from .env import encoder_ok
        from .widgets import refresh_codec_combo
        for combo in self.codec_combos():
            refresh_codec_combo(combo, encoder_ok)
        self._refresh_output()

    def _refresh_output(self, force: bool = False):
        if not self._input_path:
            return
        source_audio = ((self._info or {}).get("audio") or {}).get("codec")
        self._output.set_suggested(
            suggest_output_path(self._input_path, self.output_codec(),
                                audio_only=self.is_audio_only(),
                                source_audio_codec=source_audio),
            force=force)

    def source_audio_codec(self) -> str:
        return ((self._info or {}).get("audio") or {}).get("codec") or ""

    def source_channels(self):
        audio = (self._info or {}).get("audio") or {}
        try:
            return int(audio.get("channels")) or None
        except (TypeError, ValueError):
            return None

    def source_sample_rate(self):
        audio = (self._info or {}).get("audio") or {}
        return audio.get("sample_rate") or None

    def source_size(self):
        video = (self._info or {}).get("video") or {}
        if video.get("width") and video.get("height"):
            return (video["width"], video["height"])
        return None
