# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

BG         = "#F2F8F4"
SURFACE    = "#FFFFFF"
SURFACE_HI = "#E6F4EB"
INPUT      = "#F6FBF8"
ACCENT_BG  = "#DDF1E4"
BORDER     = "#D3E6DA"
BORDER_HI  = "#A9CDB8"
INPUT_BORDER = "#5E9577"

PRIMARY         = "#15803D"
PRIMARY_HOVER   = "#166534"
PRIMARY_PRESSED = "#14532D"
ON_PRIMARY      = "#FFFFFF"
LOGO_TOP        = "#34D399"
LOGO_BOTTOM     = "#15803D"

TEXT       = "#0E2A1B"
TEXT_DIM   = "#3B5E4C"
TEXT_FAINT = "#56766A"

ERROR    = "#B91C1C"
ERROR_BG = "#FEF2F2"
WARN     = "#B45309"
WARN_BG  = "#FFFBEB"
