# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import os

from . import theme as t

_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets").replace("\\", "/")


def _url(name: str) -> str:
    return 'url("%s/%s")' % (_ASSETS, name)


STYLES = """
QMainWindow, QDialog, QMessageBox {
    background-color: %(BG)s;
}
QWidget {
    color: %(TEXT)s;
    font-family: "Inter", "Ubuntu", "Cantarell", "Noto Sans", "DejaVu Sans", sans-serif;
    font-size: 13px;
}
QWidget#central, QWidget#content { background-color: %(BG)s; }
QLabel, QCheckBox, QRadioButton { background: transparent; }
QScrollArea { background: transparent; border: none; }
QToolTip {
    background-color: %(SURFACE_HI)s; color: %(TEXT)s;
    border: 1px solid %(BORDER_HI)s; padding: 4px 8px;
}

QWidget#header { background-color: %(SURFACE)s; border-bottom: 1px solid %(BORDER)s; }
QLabel#app-title { font-size: 17px; font-weight: 700; color: %(TEXT)s; }
QLabel#app-subtitle { font-size: 11px; color: %(TEXT_FAINT)s; }

QWidget#mode-toggle {
    background-color: %(BG)s; border: 1px solid %(BORDER)s; border-radius: 8px;
}
QPushButton#mode-btn {
    background: transparent; border: none; border-radius: 6px;
    padding: 6px 18px; font-size: 12px; font-weight: 500;
    color: %(TEXT_DIM)s; min-width: 72px;
}
QPushButton#mode-btn:hover:!checked { color: %(PRIMARY_HOVER)s; }
QPushButton#mode-btn:checked { background-color: %(PRIMARY)s; color: %(ON_PRIMARY)s; font-weight: 700; }

QWidget#section {
    background-color: %(SURFACE)s; border: 1px solid %(BORDER)s; border-radius: 10px;
}
QLabel#section-label { font-size: 11px; font-weight: 700; color: %(PRIMARY)s; }
QLabel#field-label { font-size: 12px; color: %(TEXT_DIM)s; }
QLabel#hint, QLabel#drop-hint { font-size: 11px; color: %(TEXT_FAINT)s; }
QLabel#value-label { font-size: 13px; font-weight: 700; color: %(PRIMARY)s; }

QFrame#drop-zone {
    background-color: %(INPUT)s; border: 2px dashed %(INPUT_BORDER)s; border-radius: 10px;
}
QFrame#drop-zone:hover, QFrame#drop-zone[drag-active="true"] {
    background-color: %(SURFACE_HI)s; border-color: %(PRIMARY)s;
}
QLabel#drop-text { font-size: 13px; font-weight: 600; color: %(TEXT)s; }

QLabel#info-chip {
    font-size: 11px; font-weight: 600; color: %(PRIMARY_HOVER)s; background-color: %(ACCENT_BG)s;
    border: 1px solid %(BORDER_HI)s; border-radius: 9px; padding: 2px 9px;
}

QLineEdit, QSpinBox, QComboBox, QTextEdit {
    background-color: %(INPUT)s; border: 1px solid %(INPUT_BORDER)s; border-radius: 7px;
    padding: 7px 10px; color: %(TEXT)s; selection-background-color: %(PRIMARY)s;
    selection-color: %(ON_PRIMARY)s;
}
QLineEdit:hover, QSpinBox:hover, QComboBox:hover { border-color: %(PRIMARY)s; }
QLineEdit:focus, QSpinBox:focus, QComboBox:focus, QTextEdit:focus { border-color: %(PRIMARY)s; }
QLineEdit:disabled, QSpinBox:disabled, QComboBox:disabled { color: %(TEXT_FAINT)s; background-color: %(BG)s; border-color: %(BORDER)s; }
QLineEdit, QSpinBox, QComboBox { min-height: 20px; }
QLineEdit { font-size: 12px; }
QSpinBox { min-width: 70px; }
QSpinBox::up-button, QSpinBox::down-button { width: 0; border: none; }

QComboBox { min-width: 90px; padding-right: 26px; }
QComboBox::drop-down { subcontrol-origin: padding; subcontrol-position: center right; width: 24px; border: none; }
QComboBox::down-arrow { image: %(ARROW)s; width: 12px; height: 12px; }
QComboBox QAbstractItemView {
    background-color: %(SURFACE)s; color: %(TEXT)s; border: 1px solid %(BORDER_HI)s;
    selection-background-color: %(PRIMARY)s; selection-color: %(ON_PRIMARY)s; outline: none; padding: 3px;
}
QAbstractItemView {
    background-color: %(INPUT)s; color: %(TEXT)s; border: 1px solid %(BORDER)s;
    selection-background-color: %(PRIMARY)s; selection-color: %(ON_PRIMARY)s; outline: none;
}
QHeaderView::section {
    background-color: %(SURFACE)s; color: %(TEXT_DIM)s; border: none; padding: 4px 8px;
}

QTextEdit#cmd-preview {
    background-color: %(INPUT)s; color: %(PRIMARY_PRESSED)s; border: 1px solid %(INPUT_BORDER)s; border-radius: 7px;
    padding: 10px 12px; font-family: "JetBrains Mono", "Fira Code", "Ubuntu Mono", "DejaVu Sans Mono", monospace;
    font-size: 11px;
}

QSlider { min-height: 24px; }
QSlider::groove:horizontal { height: 6px; background: %(BORDER_HI)s; border-radius: 3px; }
QSlider::sub-page:horizontal { background: %(PRIMARY)s; border-radius: 3px; }
QSlider::handle:horizontal {
    width: 14px; height: 14px; margin: -7px 0; border-radius: 10px;
    background: %(SURFACE)s; border: 3px solid %(PRIMARY)s;
}
QSlider::handle:horizontal:hover { border-color: %(PRIMARY_HOVER)s; }

QCheckBox, QRadioButton { spacing: 8px; font-size: 13px; }
QCheckBox:disabled, QRadioButton:disabled { color: %(TEXT_FAINT)s; }
QCheckBox::indicator {
    width: 16px; height: 16px; border: 2px solid %(INPUT_BORDER)s; border-radius: 5px; background: %(SURFACE)s;
}
QCheckBox::indicator:hover { border-color: %(PRIMARY)s; }
QCheckBox::indicator:checked { background: %(PRIMARY)s; border-color: %(PRIMARY)s; image: %(CHECK)s; }
QRadioButton::indicator { width: 18px; height: 18px; image: %(RADIO_OFF)s; }
QRadioButton::indicator:checked { image: %(RADIO_ON)s; }

QPushButton {
    background-color: %(SURFACE)s; border: 1px solid %(INPUT_BORDER)s; border-radius: 7px;
    padding: 7px 16px; color: %(TEXT)s;
}
QPushButton:hover { background-color: %(SURFACE_HI)s; border-color: %(PRIMARY)s; color: %(PRIMARY_HOVER)s; }
QPushButton:pressed { background-color: %(ACCENT_BG)s; }
QPushButton:disabled { color: %(TEXT_FAINT)s; border-color: %(BORDER)s; background-color: %(BG)s; }
QPushButton:focus { border-color: %(PRIMARY)s; }

QPushButton#primary {
    background-color: %(PRIMARY)s; border: none; color: %(ON_PRIMARY)s;
    font-weight: 700; font-size: 14px; padding: 11px 26px; border-radius: 8px;
}
QPushButton#primary:hover { background-color: %(PRIMARY_HOVER)s; color: %(ON_PRIMARY)s; }
QPushButton#primary:pressed { background-color: %(PRIMARY_PRESSED)s; }
QPushButton#primary:disabled { background-color: %(BORDER)s; color: %(TEXT_FAINT)s; border: none; }
QPushButton#primary[mode="cancel"] {
    background-color: transparent; border: 2px solid %(ERROR)s; color: %(ERROR)s;
}
QPushButton#primary[mode="cancel"]:hover { background-color: %(ERROR)s; color: %(ON_PRIMARY)s; }

QProgressBar { background-color: %(BORDER_HI)s; border: none; border-radius: 3px; max-height: 6px; min-height: 6px; }
QProgressBar::chunk { background-color: %(PRIMARY)s; border-radius: 3px; }

QWidget#footer { background-color: %(SURFACE)s; border-top: 1px solid %(BORDER)s; }
QLabel#status { font-size: 12px; color: %(TEXT_DIM)s; }
QLabel#status[state="ok"]    { color: %(PRIMARY_HOVER)s; font-weight: 600; }
QLabel#status[state="error"] { color: %(ERROR)s; font-weight: 600; }
QLabel#status[state="warn"]  { color: %(WARN)s; font-weight: 600; }

QFrame#banner {
    background-color: %(ACCENT_BG)s; border: 1px solid %(BORDER_HI)s; border-left: 4px solid %(PRIMARY)s;
    border-radius: 8px;
}
QFrame#banner[level="error"] { background-color: %(ERROR_BG)s; border-left-color: %(ERROR)s; border-color: %(ERROR)s; }
QFrame#banner[level="warn"]  { background-color: %(WARN_BG)s; border-left-color: %(WARN)s; border-color: %(WARN)s; }
QLabel#banner-text { color: %(TEXT)s; font-size: 12px; }

QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: %(INPUT_BORDER)s; border-radius: 3px; min-height: 30px; }
QScrollBar::handle:vertical:hover { background: %(PRIMARY)s; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
QScrollBar:horizontal { background: transparent; height: 10px; margin: 2px; }
QScrollBar::handle:horizontal { background: %(INPUT_BORDER)s; border-radius: 3px; min-width: 30px; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
""" % {
    "BG": t.BG, "SURFACE": t.SURFACE, "SURFACE_HI": t.SURFACE_HI, "INPUT": t.INPUT,
    "BORDER": t.BORDER, "BORDER_HI": t.BORDER_HI, "PRIMARY": t.PRIMARY,
    "PRIMARY_HOVER": t.PRIMARY_HOVER, "PRIMARY_PRESSED": t.PRIMARY_PRESSED,
    "ON_PRIMARY": t.ON_PRIMARY, "TEXT": t.TEXT, "TEXT_DIM": t.TEXT_DIM,
    "TEXT_FAINT": t.TEXT_FAINT, "ERROR": t.ERROR, "WARN": t.WARN,
    "INPUT_BORDER": t.INPUT_BORDER, "ACCENT_BG": t.ACCENT_BG, "ERROR_BG": t.ERROR_BG, "WARN_BG": t.WARN_BG,
    "ARROW": _url("arrow_down.png"), "CHECK": _url("check.png"),
    "RADIO_ON": _url("radio_on.png"), "RADIO_OFF": _url("radio_off.png"),
}
