# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QHBoxLayout, QLabel,
                             QRadioButton, QSizePolicy, QSlider, QVBoxLayout, QWidget)

from .base_view import BaseView
from .core import SPEED_PRESETS
from .env import encoder_ok
from .widgets import fill_codec_combo, field, section


class BasicView(BaseView):
    _CODECS = [
        ("H.264 — fast, plays everywhere", "libx264"),
        ("H.265 — about 40% smaller, slower", "libx265"),
        ("VP9 — small, web-friendly", "libvpx-vp9"),
        ("VP8 — older, wide support", "libvpx"),
        ("AV1 — smallest, very slow", "libaom-av1"),
    ]
    _AUDIO_ONLY_FORMATS = [
        ("MP3", "libmp3lame"),
        ("AAC (m4a)", "aac"),
        ("Opus", "libopus"),
        ("FLAC (lossless)", "flac"),
        ("WAV (lossless)", "pcm_s16le"),
    ]
    _AUDIO_BITRATES = [96, 128, 192, 256, 320]
    _RESOLUTIONS = [("Same as input", "original"), ("4K (2160p)", "4k"), ("1440p", "1440p"),
                    ("1080p", "1080p"), ("720p", "720p"), ("480p", "480p"), ("360p", "360p")]

    def __init__(self, parent=None):
        super().__init__(parent)
        root = self.root

        self._quality = QSlider(Qt.Orientation.Horizontal)
        self._quality.setRange(0, 100)
        self._quality.setValue(65)
        self._quality.valueChanged.connect(self._on_quality_changed)
        self._qual_label = QLabel("65")
        self._qual_label.setObjectName("value-label")
        ends = QHBoxLayout()
        small = QLabel("Smaller file")
        small.setObjectName("hint")
        better = QLabel("Better quality")
        better.setObjectName("hint")
        ends.addWidget(small)
        ends.addStretch()
        ends.addWidget(self._qual_label)
        ends.addStretch()
        ends.addWidget(better)
        qual_box = QVBoxLayout()
        qual_box.setSpacing(6)
        qual_box.addLayout(ends)
        qual_box.addWidget(self._quality)
        self._quality_section = section("Quality", qual_box)
        root.addWidget(self._quality_section)

        self._codec = QComboBox()
        self._codec.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        fill_codec_combo(self._codec, self._CODECS, encoder_ok)
        self._codec.currentIndexChanged.connect(lambda _: self._refresh_output())

        self._resolution = QComboBox()
        for label, key in self._RESOLUTIONS:
            self._resolution.addItem(label, key)
        self._resolution.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        speed_row = QHBoxLayout()
        speed_row.setSpacing(14)
        self._speed_group = QButtonGroup(self)
        for label in SPEED_PRESETS:
            rb = QRadioButton(label)
            rb.setChecked(label == "Balanced")
            self._speed_group.addButton(rb)
            speed_row.addWidget(rb)
        speed_row.addStretch()
        speed_box = QVBoxLayout()
        speed_box.setSpacing(5)
        cap = QLabel("Encoding speed")
        cap.setObjectName("field-label")
        speed_box.addWidget(cap)
        speed_box.addLayout(speed_row)

        res_speed = QHBoxLayout()
        res_speed.setSpacing(18)
        res_box = field("Resolution", self._resolution)
        res_speed.addLayout(res_box, 1)
        res_speed.addLayout(speed_box, 1)
        res_speed.setAlignment(res_box, Qt.AlignmentFlag.AlignTop)
        res_speed.setAlignment(speed_box, Qt.AlignmentFlag.AlignTop)

        self._video_section = section("Video format", field("Codec", self._codec), res_speed)
        root.addWidget(self._video_section)

        audio_row = QHBoxLayout()
        audio_row.setSpacing(16)
        self._audio_group = QButtonGroup(self)
        for label in ("Stereo", "Mono", "Mute"):
            rb = QRadioButton(label)
            rb.setChecked(label == "Stereo")
            self._audio_group.addButton(rb)
            audio_row.addWidget(rb)
        audio_row.addStretch()
        self._audio_section = section("Audio", audio_row)
        root.addWidget(self._audio_section)

        self._audio_only_cb = QCheckBox("Extract audio only (no video)")
        self._audio_only_cb.toggled.connect(self._on_audio_only_toggled)
        self._audio_only_format = QComboBox()
        fill_codec_combo(self._audio_only_format, self._AUDIO_ONLY_FORMATS, encoder_ok)
        self._audio_only_format.currentIndexChanged.connect(self._on_audio_format_changed)
        self._audio_only_format.setEnabled(False)
        self._audio_bitrate = QComboBox()
        for kbps in self._AUDIO_BITRATES:
            self._audio_bitrate.addItem("%d kbps" % kbps, kbps)
        self._audio_bitrate.setCurrentIndex(self._AUDIO_BITRATES.index(192))
        self._audio_bitrate.setEnabled(False)

        ao_row = QHBoxLayout()
        ao_row.setSpacing(10)
        ao_row.addWidget(self._audio_only_cb)
        ao_row.addWidget(self._audio_only_format)
        ao_row.addWidget(self._audio_bitrate)
        ao_row.addStretch()

        self._strip_meta = QCheckBox("Strip metadata (GPS, camera info, chapters)")
        tip = QLabel("Tip: “Smaller” encoding speed takes longer but shrinks the file more.")
        tip.setObjectName("hint")
        tip.setWordWrap(True)
        self._tip = tip
        root.addWidget(section("Options", ao_row, self._strip_meta, tip))
        root.addStretch()

    def codec_combos(self):
        return [self._codec, self._audio_only_format]

    def is_audio_only(self) -> bool:
        return self._audio_only_cb.isChecked()

    def output_codec(self) -> str:
        combo = self._audio_only_format if self.is_audio_only() else self._codec
        return combo.currentData() or "libx264"

    def _on_quality_changed(self, value: int):
        self._qual_label.setText(str(value))

    def _on_audio_format_changed(self, _index=None):
        lossless = self._audio_only_format.currentData() in ("flac", "pcm_s16le")
        self._audio_bitrate.setEnabled(self.is_audio_only() and not lossless)
        self._refresh_output()

    def _on_audio_only_toggled(self, checked: bool):
        for w in (self._quality_section, self._video_section, self._audio_section, self._tip):
            w.setVisible(not checked)
        self._audio_only_format.setEnabled(checked)
        self._on_audio_format_changed()

    def get_settings(self) -> dict:
        audio_only = self.is_audio_only()
        speed_label = next((b.text() for b in self._speed_group.buttons() if b.isChecked()), "Balanced")
        audio_btn = next((b.text() for b in self._audio_group.buttons() if b.isChecked()), "Stereo")
        audio_mode, channels = "transcode", 2
        if audio_btn == "Mute":
            audio_mode, channels = "none", None
        elif audio_btn == "Mono":
            channels = 1

        settings = {
            "input": self._input_path,
            "output": self._output.path,
            "audio_only": audio_only,
            "codec": self._codec.currentData() or "libx264",
            "quality": self._quality.value(),
            "preset": SPEED_PRESETS.get(speed_label, "medium"),
            "resolution": self._resolution.currentData(),
            "pix_fmt": "yuv420p",
            "audio_mode": audio_mode,
            "audio_channels": channels,
            "audio_bitrate": 64 if audio_btn == "Mono" else 128,
            "strip_metadata": self._strip_meta.isChecked(),
            "source_size": self.source_size(),
            "source_audio_codec": self.source_audio_codec(),
            "source_channels": self.source_channels(),
            "source_sample_rate": self.source_sample_rate(),
        }
        if audio_only:
            settings["audio_codec"] = self._audio_only_format.currentData()
            settings["audio_bitrate"] = self._audio_bitrate.currentData()
            settings["audio_channels"] = None
        return settings
