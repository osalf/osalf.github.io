# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

from PyQt6.QtGui import QTextOption
from PyQt6.QtWidgets import (QCheckBox, QComboBox, QGridLayout, QHBoxLayout, QLabel,
                             QLineEdit, QSizePolicy, QSpinBox, QTextEdit, QVBoxLayout)

from .base_view import BaseView
from .core import CRF_MIN, DEFAULT_CRF, build_command, format_command_str
from .env import encoder_ok
from .widgets import field, fill_codec_combo, section

_X26X = ("libx264", "libx265")
_CRF_MAX = {"libx264": 51, "libx265": 51}


class AdvancedView(BaseView):
    _CODECS = [
        ("H.264 (libx264)", "libx264"),
        ("H.265 (libx265)", "libx265"),
        ("VP9 (libvpx-vp9)", "libvpx-vp9"),
        ("VP8 (libvpx)", "libvpx"),
        ("AV1 (libaom-av1)", "libaom-av1"),
    ]
    _RESOLUTIONS = [("Original", "original"), ("4K (2160p)", "4k"), ("1440p", "1440p"),
                    ("1080p", "1080p"), ("720p", "720p"), ("480p", "480p"), ("360p", "360p")]
    _PRESETS = ["ultrafast", "superfast", "veryfast", "faster", "fast",
                "medium", "slow", "slower", "veryslow"]
    _TUNES = {
        "libx264": ["none", "film", "animation", "grain", "stillimage", "fastdecode", "zerolatency"],
        "libx265": ["none", "animation", "grain", "fastdecode", "zerolatency"],
    }
    _PROFILES = ["auto", "baseline", "main", "high"]
    _PIX_FMTS = ["yuv420p", "yuv422p", "yuv444p", "yuv420p10le", "yuv422p10le"]
    _FPS = ["Original", "60", "30", "25", "24", "15"]
    _AUDIO_CODECS = [(n, n) for n in
                     ("aac", "libopus", "libmp3lame", "ac3", "flac", "pcm_s16le", "libvorbis", "copy")]
    _AUDIO_MODES = ["Transcode", "Copy (no re-encode)", "Remove audio"]
    _SAMPLE_RATES = [("Original", "original"), ("48000", "48000"), ("44100", "44100"), ("22050", "22050")]
    _CHANNELS = ["Original", "2 (Stereo)", "1 (Mono)"]

    def __init__(self, parent=None):
        super().__init__(parent)
        root = self.root

        self._output_mode = QComboBox()
        self._output_mode.addItems(["Video", "Audio only"])
        self._output_mode.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        root.addWidget(section("Output type", self._output_mode))

        self._codec = QComboBox()
        fill_codec_combo(self._codec, self._CODECS, encoder_ok)
        self._res = self._combo_of([(l, k) for l, k in self._RESOLUTIONS])
        self._fps = self._combo_of([(f, f) for f in self._FPS])

        self._use_crf = QCheckBox("Constant quality (CRF)")
        self._use_crf.setChecked(True)
        self._crf_spin = QSpinBox()
        self._crf_spin.setToolTip("Lower = better quality / larger file")
        self._crf_hint = QLabel("lower = better quality")
        self._crf_hint.setObjectName("hint")
        self._vbitrate = QSpinBox()
        self._vbitrate.setRange(50, 200000)
        self._vbitrate.setValue(2500)
        self._vbitrate.setSuffix(" kbps")
        self._vbitrate.setToolTip("Target video bitrate")
        self._vbitrate.hide()
        quality_row = QHBoxLayout()
        quality_row.setSpacing(12)
        quality_row.addWidget(self._use_crf)
        quality_row.addWidget(self._crf_spin)
        quality_row.addWidget(self._vbitrate)
        quality_row.addWidget(self._crf_hint)
        quality_row.addStretch()

        self._preset = self._combo_of([(p, p) for p in self._PRESETS], default="medium")
        self._tune = QComboBox()
        self._profile = self._combo_of([(p, p) for p in self._PROFILES], default="high")
        self._pix_fmt = self._combo_of([(p, p) for p in self._PIX_FMTS])

        top = QGridLayout()
        top.setHorizontalSpacing(14)
        top.setVerticalSpacing(10)
        top.addLayout(field("Codec", self._codec), 0, 0)
        top.addLayout(field("Resolution", self._res), 0, 1)
        top.addLayout(field("Frame rate", self._fps), 0, 2)
        bottom = QGridLayout()
        bottom.setHorizontalSpacing(14)
        bottom.addLayout(field("Preset", self._preset), 0, 0)
        bottom.addLayout(field("Tune", self._tune), 0, 1)
        bottom.addLayout(field("Profile", self._profile), 0, 2)
        bottom.addLayout(field("Pixel format", self._pix_fmt), 0, 3)
        for grid, cols in ((top, 3), (bottom, 4)):
            for c in range(cols):
                grid.setColumnStretch(c, 1)
        self._video_section = section("Video", top, quality_row, bottom)
        root.addWidget(self._video_section)

        self._audio_mode = self._combo_of([(m, m) for m in self._AUDIO_MODES])
        self._audio_codec = QComboBox()
        fill_codec_combo(self._audio_codec, self._AUDIO_CODECS, encoder_ok)
        self._audio_bitrate = QSpinBox()
        self._audio_bitrate.setRange(8, 512)
        self._audio_bitrate.setValue(128)
        self._audio_bitrate.setSuffix(" kbps")
        self._audio_ch = self._combo_of([(c, c) for c in self._CHANNELS])
        self._audio_sr = self._combo_of(self._SAMPLE_RATES)
        agrid = QGridLayout()
        agrid.setHorizontalSpacing(14)
        agrid.setVerticalSpacing(10)
        agrid.addLayout(field("Mode", self._audio_mode), 0, 0)
        agrid.addLayout(field("Codec", self._audio_codec), 0, 1)
        agrid.addLayout(field("Bitrate", self._audio_bitrate), 0, 2)
        agrid.addLayout(field("Channels", self._audio_ch), 1, 0)
        agrid.addLayout(field("Sample rate", self._audio_sr), 1, 1)
        for c in range(3):
            agrid.setColumnStretch(c, 1)
        root.addWidget(section("Audio", agrid))

        self._denoise = QCheckBox("Denoise (hqdn3d)")
        self._strip_meta = QCheckBox("Strip metadata")
        self._strip_ch = QCheckBox("Strip chapters")
        frow = QHBoxLayout()
        frow.setSpacing(22)
        for cb in (self._denoise, self._strip_meta, self._strip_ch):
            frow.addWidget(cb)
        frow.addStretch()
        root.addWidget(section("Filters & cleanup", frow))

        self._extra = QLineEdit()
        self._extra.setPlaceholderText("e.g. -movflags +faststart   or   -metadata title=\"My clip\"")
        note = QLabel("Extra ffmpeg flags, added before the output file (quotes are supported):")
        note.setObjectName("hint")
        note.setWordWrap(True)
        root.addWidget(section("Extra flags", note, self._extra))

        self._preview = QTextEdit()
        self._preview.setObjectName("cmd-preview")
        self._preview.setReadOnly(True)
        self._preview.setMinimumHeight(110)
        self._preview.setMaximumHeight(170)
        self._preview.setWordWrapMode(QTextOption.WrapMode.WrapAnywhere)
        root.addWidget(section("ffmpeg command preview", self._preview))
        root.addStretch()

        self._codec.currentIndexChanged.connect(self._on_codec_changed)
        self._output_mode.currentIndexChanged.connect(self._on_output_mode_changed)
        self._use_crf.toggled.connect(self._on_quality_mode_changed)
        self._audio_mode.currentIndexChanged.connect(self._update_audio_enabled)
        self._audio_codec.currentIndexChanged.connect(self._update_audio_enabled)
        self._audio_codec.currentIndexChanged.connect(lambda _: self._refresh_output())
        for w in (self._res, self._fps, self._preset, self._tune, self._profile, self._pix_fmt,
                  self._audio_ch, self._audio_sr):
            w.currentIndexChanged.connect(self._refresh_preview)
        for w in (self._crf_spin, self._vbitrate, self._audio_bitrate):
            w.valueChanged.connect(self._refresh_preview)
        for cb in (self._denoise, self._strip_meta, self._strip_ch):
            cb.toggled.connect(self._refresh_preview)
        self._extra.textChanged.connect(self._refresh_preview)

        self._on_codec_changed()
        self._update_audio_enabled()

    @staticmethod
    def _combo_of(entries, default=None):
        combo = QComboBox()
        for label, value in entries:
            combo.addItem(label, value)
        if default is not None:
            idx = combo.findData(default)
            if idx >= 0:
                combo.setCurrentIndex(idx)
        return combo

    def codec_combos(self):
        return [self._codec, self._audio_codec]

    def is_audio_only(self) -> bool:
        return self._output_mode.currentIndex() == 1

    def output_codec(self) -> str:
        combo = self._audio_codec if self.is_audio_only() else self._codec
        return combo.currentData() or "libx264"

    def _refresh_output(self, force: bool = False):
        super()._refresh_output(force)
        self._refresh_preview()

    def _on_info_changed(self):
        self._refresh_preview()

    def _on_codec_changed(self, _index=None):
        codec = self._codec.currentData() or "libx264"
        self._crf_spin.blockSignals(True)
        self._crf_spin.setRange(CRF_MIN.get(codec, 0), _CRF_MAX.get(codec, 63))
        self._crf_spin.setValue(DEFAULT_CRF.get(codec, 23))
        self._crf_spin.blockSignals(False)

        tunes = self._TUNES.get(codec)
        self._tune.blockSignals(True)
        self._tune.clear()
        for t in (tunes or ["none"]):
            self._tune.addItem(t, t)
        self._tune.blockSignals(False)
        self._tune.setEnabled(bool(tunes))
        self._profile.setEnabled(codec == "libx264")
        self._refresh_output()

    def _on_quality_mode_changed(self, use_crf: bool):
        self._crf_spin.setVisible(use_crf)
        self._crf_hint.setVisible(use_crf)
        self._vbitrate.setVisible(not use_crf)
        self._refresh_preview()

    def _on_output_mode_changed(self, _index=None):
        audio_only = self.is_audio_only()
        self._video_section.setVisible(not audio_only)
        self._audio_mode.setEnabled(not audio_only)
        if audio_only:
            self._audio_mode.setCurrentIndex(0)
        self._update_audio_enabled()
        self._refresh_output()

    def _update_audio_enabled(self, _index=None):
        transcode = self._audio_mode.currentIndex() == 0 or self.is_audio_only()
        codec = self._audio_codec.currentData()
        encoding = transcode and codec != "copy"
        self._audio_codec.setEnabled(transcode)
        self._audio_bitrate.setEnabled(encoding and codec not in ("flac", "pcm_s16le"))
        self._audio_ch.setEnabled(encoding)
        self._audio_sr.setEnabled(encoding)
        self._refresh_preview()

    def _refresh_preview(self, *_args):
        if not self._input_path:
            self._preview.setPlainText("# Choose an input file to see the ffmpeg command.")
            return
        try:
            self._preview.setPlainText(format_command_str(build_command(self.get_settings())))
        except Exception as exc:
            self._preview.setPlainText("# %s" % exc)

    def get_settings(self) -> dict:
        audio_only = self.is_audio_only()
        fps = self._fps.currentData()

        mode_idx = self._audio_mode.currentIndex()
        audio_mode = "copy" if mode_idx == 1 else ("none" if mode_idx == 2 else "transcode")
        ch = self._audio_ch.currentText()
        channels = 1 if "Mono" in ch else (2 if "Stereo" in ch else None)

        tune = self._tune.currentData() or "none"
        profile = self._profile.currentData() or "auto"
        use_crf = self._use_crf.isChecked()
        return {
            "input": self._input_path,
            "output": self._output.path,
            "audio_only": audio_only,
            "codec": self._codec.currentData() or "libx264",
            "crf": self._crf_spin.value() if use_crf else None,
            "video_bitrate": None if use_crf else self._vbitrate.value(),
            "preset": self._preset.currentData(),
            "tune": "" if tune == "none" else tune,
            "profile": "" if profile == "auto" or not self._profile.isEnabled() else profile,
            "resolution": self._res.currentData(),
            "fps": "original" if fps == "Original" else fps,
            "pix_fmt": self._pix_fmt.currentData(),
            "audio_mode": audio_mode,
            "audio_codec": self._audio_codec.currentData(),
            "audio_bitrate": self._audio_bitrate.value(),
            "audio_channels": channels,
            "audio_sample_rate": self._audio_sr.currentData(),
            "strip_metadata": self._strip_meta.isChecked(),
            "strip_chapters": self._strip_ch.isChecked(),
            "denoise": self._denoise.isChecked(),
            "custom_args": self._extra.text(),
            "source_size": self.source_size(),
            "source_audio_codec": self.source_audio_codec(),
            "source_channels": self.source_channels(),
            "source_sample_rate": self.source_sample_rate(),
        }
