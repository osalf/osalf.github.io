# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

import os
from typing import Optional

from PyQt6.QtCore import Qt, QTimer, pyqtSlot
from PyQt6.QtGui import QGuiApplication, QIcon
from PyQt6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QMainWindow, QMessageBox,
                             QProgressBar, QPushButton, QScrollArea, QStackedWidget,
                             QVBoxLayout, QWidget)

from . import env
from .advanced_view import AdvancedView
from .basic_view import BasicView
from .core import FFmpegWorker, build_command, fmt_size, probe_video
from .styles import STYLES
from .widgets import Logo, repolish


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Klem")
        self.setMinimumSize(540, 520)
        avail = QGuiApplication.primaryScreen().availableGeometry() if QGuiApplication.primaryScreen() else None
        height = 800 if avail is None else min(800, max(520, avail.height() - 80))
        self.resize(660, height)
        self.setStyleSheet(STYLES)
        icon_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "icon.png")
        icon = QIcon(icon_file) if os.path.isfile(icon_file) else QIcon.fromTheme("klem")
        self.setWindowIcon(icon)

        self._worker: Optional[FFmpegWorker] = None
        self._video_info: Optional[dict] = None
        self._last_output = ""
        self._input_size = 0

        central = QWidget()
        central.setObjectName("central")
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._build_header())
        self._banner = self._build_banner()
        root.addWidget(self._banner)
        root.addWidget(self._build_content(), 1)
        root.addWidget(self._build_footer())

        QTimer.singleShot(0, self._check_tools)

    def _build_header(self) -> QWidget:
        header = QWidget()
        header.setObjectName("header")
        header.setFixedHeight(68)
        layout = QHBoxLayout(header)
        layout.setContentsMargins(18, 0, 18, 0)
        layout.setSpacing(12)
        layout.addWidget(Logo(46), 0, Qt.AlignmentFlag.AlignVCenter)
        layout.addStretch()

        toggle = QWidget()
        toggle.setObjectName("mode-toggle")
        toggle.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        tl = QHBoxLayout(toggle)
        tl.setContentsMargins(3, 3, 3, 3)
        tl.setSpacing(2)
        self._basic_btn = QPushButton("Basic")
        self._adv_btn = QPushButton("Advanced")
        for idx, btn in enumerate((self._basic_btn, self._adv_btn)):
            btn.setObjectName("mode-btn")
            btn.setCheckable(True)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _checked=False, i=idx: self._set_mode(i))
            tl.addWidget(btn)
        self._basic_btn.setChecked(True)
        layout.addWidget(toggle, 0, Qt.AlignmentFlag.AlignVCenter)
        return header

    def _build_banner(self) -> QFrame:
        banner = QFrame()
        banner.setObjectName("banner")
        banner.setProperty("level", "warn")
        lay = QHBoxLayout(banner)
        lay.setContentsMargins(14, 10, 10, 10)
        self._banner_text = QLabel("")
        self._banner_text.setObjectName("banner-text")
        self._banner_text.setWordWrap(True)
        self._banner_text.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        recheck = QPushButton("Check again")
        recheck.clicked.connect(self._check_tools)
        lay.addWidget(self._banner_text, 1)
        lay.addWidget(recheck)
        banner.hide()
        outer = QWidget()
        outer_lay = QVBoxLayout(outer)
        outer_lay.setContentsMargins(18, 12, 18, 0)
        outer_lay.addWidget(banner)
        outer.hide()
        self._banner_frame = banner
        self._banner_outer = outer
        return outer

    def _build_content(self) -> QScrollArea:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        self._stack = QStackedWidget()
        self._stack.setObjectName("content")
        self._basic = BasicView()
        self._adv = AdvancedView()
        self._stack.addWidget(self._basic)
        self._stack.addWidget(self._adv)
        scroll.setWidget(self._stack)
        self._basic._audio_only_cb.toggled.connect(lambda _c: self._update_button_text())
        self._adv._output_mode.currentIndexChanged.connect(lambda _i: self._update_button_text())
        for view in (self._basic, self._adv):
            view.file_selected.connect(self._on_file_selected)
            view.message.connect(lambda text: self._set_status(text, state="error"))
        return scroll

    def _build_footer(self) -> QWidget:
        footer = QWidget()
        footer.setObjectName("footer")
        layout = QVBoxLayout(footer)
        layout.setContentsMargins(18, 12, 18, 16)
        layout.setSpacing(10)

        self._progress = QProgressBar()
        self._progress.setTextVisible(False)
        self._progress.hide()
        layout.addWidget(self._progress)

        bottom = QHBoxLayout()
        bottom.setSpacing(10)
        self._status = QLabel("")
        self._status.setObjectName("status")
        self._status.setWordWrap(True)
        bottom.addWidget(self._status, 1)

        self._folder_btn = QPushButton("Show in folder")
        self._folder_btn.clicked.connect(self._show_in_folder)
        self._folder_btn.hide()
        bottom.addWidget(self._folder_btn)

        self._compress_btn = QPushButton("Compress Video")
        self._compress_btn.setObjectName("primary")
        self._compress_btn.setMinimumWidth(170)
        self._compress_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._compress_btn.clicked.connect(self._on_compress_clicked)
        bottom.addWidget(self._compress_btn)
        layout.addLayout(bottom)
        return footer

    def _current_view(self):
        return self._basic if self._stack.currentIndex() == 0 else self._adv

    def _set_mode(self, idx: int):
        self._stack.setCurrentIndex(idx)
        self._basic_btn.setChecked(idx == 0)
        self._adv_btn.setChecked(idx == 1)
        self._update_button_text()

    def _update_button_text(self):
        if self._worker and self._worker.isRunning():
            return
        audio_only = self._current_view().is_audio_only()
        self._compress_btn.setText("Extract Audio" if audio_only else "Compress Video")

    def _set_status(self, text: str, *, state: str = ""):
        self._status.setProperty("state", state)
        self._status.setText(text)
        repolish(self._status)

    def _show_banner(self, text: str, level: str):
        self._banner_text.setText(text)
        self._banner_frame.setProperty("level", level)
        repolish(self._banner_frame)
        self._banner_frame.show()
        self._banner_outer.show()

    def _hide_banner(self):
        self._banner_frame.hide()
        self._banner_outer.hide()

    def _set_running(self, running: bool):
        self._stack.setEnabled(not running)
        self._compress_btn.setProperty("mode", "cancel" if running else "")
        self._compress_btn.setText("Cancel" if running else "Compress Video")
        repolish(self._compress_btn)
        if not running:
            self._update_button_text()

    def _check_tools(self):
        env.available_encoders(refresh=True)
        for view in (self._basic, self._adv):
            view.refresh_encoders()
        if not env.find_tool("ffmpeg") or not env.find_tool("ffprobe"):
            self._show_banner(
                "ffmpeg isn't installed (or isn't on your PATH), so Klem can't compress anything yet.\n"
                "Install it with:  %s\n"
                "or let Klem download one for you:  klem --install-ffmpeg" % env.install_hint("ffmpeg"), "error")
            self._compress_btn.setEnabled(False)
            return
        self._compress_btn.setEnabled(True)
        if not env.encoder_ok("libx264"):
            self._show_banner(
                "Your ffmpeg has no H.264 encoder (libx264), so that option is greyed out. "
                "Pick another codec, or run 'klem --install-ffmpeg' in a terminal to download "
                "a full build.", "warn")
        else:
            self._hide_banner()

    @pyqtSlot(str)
    def _on_file_selected(self, path: str):
        self._set_status("")
        self._folder_btn.hide()
        try:
            info = probe_video(path)
        except Exception as exc:
            self._video_info = None
            self._input_size = 0
            for view in (self._basic, self._adv):
                view.set_input(path, None)
            if isinstance(exc, env.ToolMissing):
                self._set_status(str(exc), state="error")
            else:
                self._set_status("Could not read this file: %s" % exc, state="error")
            return
        self._video_info = info
        self._input_size = info.get("size", 0)
        for view in (self._basic, self._adv):
            view.set_input(path, info)
        self._progress.hide()

    def open_path(self, path: str):
        if not os.path.isfile(path):
            self._set_status("File not found: %s" % path, state="error")
            return
        self._basic._drop.set_path(path)
        self._basic._on_picked(path)

    @pyqtSlot()
    def _on_compress_clicked(self):
        if self._worker and self._worker.isRunning():
            self._worker.cancel()
            self._compress_btn.setEnabled(False)
            self._compress_btn.setText("Cancelling…")
            return

        view = self._current_view()
        settings = view.get_settings()
        problem = self._validate(settings)
        if problem:
            self._set_status(problem, state="error")
            return
        if os.path.exists(settings["output"]):
            answer = QMessageBox.question(
                self, "Replace file?",
                "“%s” already exists.\nReplace it?" % os.path.basename(settings["output"]),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes:
                return
        try:
            cmd = build_command(settings)
        except Exception as exc:
            self._set_status("Command error: %s" % exc, state="error")
            return

        duration = (self._video_info or {}).get("duration", 0) or 0
        self._last_output = settings["output"]
        worker = FFmpegWorker(cmd, duration, settings["output"], self)
        worker.progress.connect(self._on_progress)
        worker.done.connect(self._on_done)
        self._worker = worker

        self._folder_btn.hide()
        self._set_running(True)
        if duration > 0:
            self._progress.setRange(0, 100)
            self._progress.setValue(0)
        else:
            self._progress.setRange(0, 0)
        self._progress.show()
        self._set_status("Encoding…")
        worker.start()

    def _validate(self, s: dict) -> str:
        if not s.get("input"):
            return "Choose a video file first."
        if not os.path.isfile(s["input"]):
            return "The input file no longer exists."
        if not s.get("output"):
            return "The output path is empty."
        try:
            if os.path.exists(s["output"]) and os.path.samefile(s["input"], s["output"]):
                return "Output can't be the same file as the input."
        except OSError:
            pass
        out_dir = os.path.dirname(os.path.abspath(s["output"]))
        if not os.path.isdir(out_dir):
            return "The output folder doesn't exist."
        if not os.access(out_dir, os.W_OK):
            return "You don't have permission to write to the output folder."
        if s.get("audio_only") and self._video_info and not self._video_info.get("audio"):
            return "This file has no audio track to extract."
        if not s.get("audio_only") and self._video_info and not self._video_info.get("video"):
            return "This file has no video track. Use \u201cExtract audio only\u201d instead."
        return ""

    @pyqtSlot(int, str)
    def _on_progress(self, pct: int, speed: str):
        if self._progress.maximum() > 0:
            self._progress.setValue(pct)
            self._set_status("%d%%%s" % (pct, ("  ·  " + speed) if speed else ""))
        else:
            self._set_status("Encoding…%s" % (("  ·  " + speed) if speed else ""))

    @pyqtSlot(bool, str)
    def _on_done(self, success: bool, message: str):
        worker, self._worker = self._worker, None
        if worker is not None:
            worker.wait()
            worker.deleteLater()
        self._compress_btn.setEnabled(True)
        self._set_running(False)

        if success:
            self._progress.setRange(0, 100)
            self._progress.setValue(100)
            self._progress.show()
            change = 0.0
            try:
                new = os.path.getsize(message)
                text = "Done — %s  (%s)" % (os.path.basename(message), fmt_size(new))
                if self._input_size > 0:
                    change = (1 - new / float(self._input_size)) * 100
                    if change >= 1:
                        text += "  ·  %.0f%% smaller" % change
                    elif change <= -1:
                        text += "  ·  %.0f%% larger than the original" % -change
                self._set_status(text, state="ok" if change >= -1 else "warn")
            except OSError:
                self._set_status("Done!", state="ok")
            self._folder_btn.show()
        elif message == "Cancelled":
            self._progress.hide()
            self._set_status("Cancelled")
        else:
            self._progress.hide()
            self._set_status(message, state="error")

    def _show_in_folder(self):
        if self._last_output:
            env.open_folder(self._last_output)

    def closeEvent(self, event):
        worker = self._worker
        if worker is not None and worker.isRunning():
            answer = QMessageBox.question(
                self, "Quit Klem?", "A video is still being encoded. Cancel it and quit?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            worker.cancel()
            worker.wait(5000)
        event.accept()
