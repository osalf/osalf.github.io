# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

from PyQt6.QtCore import QEasingCurve, QPropertyAnimation, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QGuiApplication, QLinearGradient, QPainter, QPen
from PyQt6.QtWidgets import QHBoxLayout, QLabel, QVBoxLayout, QWidget

from . import __version__, theme
from .widgets import Logo

_FADE_PLATFORMS = {"xcb", "windows", "cocoa"}


class SplashScreen(QWidget):
    done = pyqtSignal()

    _SHOW_MS = 1400
    _FADE_MS = 280

    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint |
                            Qt.WindowType.WindowStaysOnTopHint |
                            Qt.WindowType.SplashScreen)
        self.setFixedSize(480, 340)
        self._center_on_screen()
        self._build_ui()

    def paintEvent(self, _event):
        p = QPainter(self)
        grad = QLinearGradient(0, 0, 0, self.height())
        grad.setColorAt(0.0, QColor(theme.BG))
        grad.setColorAt(1.0, QColor(theme.SURFACE))
        p.fillRect(self.rect(), grad)
        p.setPen(QPen(QColor(theme.PRIMARY), 3))
        p.drawLine(0, 1, self.width(), 1)
        p.setPen(QPen(QColor(theme.BORDER), 1))
        p.drawRect(0, 0, self.width() - 1, self.height() - 1)

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(40, 28, 40, 24)
        root.setSpacing(0)

        root.addStretch(2)
        row = QHBoxLayout()
        row.addStretch()
        row.addWidget(Logo(124))
        row.addStretch()
        root.addLayout(row)
        root.addSpacing(20)

        sub = QLabel("VIDEO COMPRESSOR")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub.setStyleSheet("background: transparent; font-size: 11px; font-weight: 600; "
                          "letter-spacing: 2px; color: %s;" % theme.PRIMARY)
        root.addWidget(sub)
        root.addStretch(3)

        ver = QLabel("v%s" % __version__)
        ver.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ver.setStyleSheet("background: transparent; font-size: 10px; color: %s;" % theme.TEXT_FAINT)
        root.addWidget(ver)

    def show_and_start(self):
        self.show()
        QTimer.singleShot(self._SHOW_MS, self._begin_fade)

    def _begin_fade(self):
        if QGuiApplication.platformName() not in _FADE_PLATFORMS:
            self._finish()
            return
        self._anim = QPropertyAnimation(self, b"windowOpacity")
        self._anim.setDuration(self._FADE_MS)
        self._anim.setStartValue(1.0)
        self._anim.setEndValue(0.0)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.finished.connect(self._finish)
        self._anim.start()

    def _finish(self):
        self.done.emit()
        self.hide()

    def _center_on_screen(self):
        screen = QGuiApplication.primaryScreen()
        if screen:
            geo = screen.availableGeometry()
            self.move(geo.center().x() - self.width() // 2,
                      geo.center().y() - self.height() // 2)
