# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import os

from PyQt6.QtCore import QPoint, QPointF, QRect, QRectF, QSettings, QSize, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QPainter, QPainterPath, QPen, QPixmap, QPolygonF
from PyQt6.QtWidgets import (QFileDialog, QFrame, QHBoxLayout, QLabel, QLayout,
                             QLineEdit, QPushButton, QSizePolicy, QVBoxLayout, QWidget)

from . import theme

VIDEO_EXTENSIONS = {
    ".mp4", ".mkv", ".mov", ".avi", ".webm",
    ".m4v", ".flv", ".wmv", ".ts", ".mts",
    ".m2ts", ".vob", ".3gp", ".3g2", ".ogv",
    ".mpg", ".mpeg", ".asf",
}


def repolish(widget: QWidget):
    style = widget.style()
    style.unpolish(widget)
    style.polish(widget)
    widget.update()


def settings() -> QSettings:
    return QSettings("ocaif", "Klem")


def last_dir() -> str:
    path = settings().value("last_dir", "", type=str)
    return path if path and os.path.isdir(path) else os.path.expanduser("~")


def remember_dir(path: str):
    directory = path if os.path.isdir(path) else os.path.dirname(path)
    if directory:
        settings().setValue("last_dir", directory)


class Glyph(QWidget):

    def __init__(self, kind: str, size: int = 40, color: str = theme.PRIMARY, parent=None):
        super().__init__(parent)
        self._kind = kind
        self._color = QColor(color)
        self.setFixedSize(size, size)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

    def set_kind(self, kind: str):
        self._kind = kind
        self.update()

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        s = float(min(self.width(), self.height()))
        draw = {"upload": self._upload, "film": self._film}[self._kind]
        draw(p, s)

    def _pen(self, s, width=0.07):
        pen = QPen(self._color, s * width)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        return pen

    def _upload(self, p, s):
        p.setPen(self._pen(s))
        p.setBrush(Qt.BrushStyle.NoBrush)
        tray = QPainterPath(QPointF(s * .14, s * .62))
        tray.lineTo(s * .14, s * .86)
        tray.lineTo(s * .86, s * .86)
        tray.lineTo(s * .86, s * .62)
        p.drawPath(tray)
        p.drawLine(QPointF(s * .5, s * .68), QPointF(s * .5, s * .14))
        p.drawLine(QPointF(s * .5, s * .14), QPointF(s * .31, s * .33))
        p.drawLine(QPointF(s * .5, s * .14), QPointF(s * .69, s * .33))

    def _film(self, p, s):
        p.setPen(self._pen(s, 0.06))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(QRectF(s * .12, s * .18, s * .76, s * .64), s * .08, s * .08)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(self._color)
        for y in (.26, .45, .64):
            p.drawRoundedRect(QRectF(s * .17, s * y, s * .08, s * .1), s * .02, s * .02)
            p.drawRoundedRect(QRectF(s * .75, s * y, s * .08, s * .1), s * .02, s * .02)
        p.drawPolygon(QPolygonF([QPointF(s * .42, s * .36), QPointF(s * .42, s * .64),
                                 QPointF(s * .62, s * .5)]))


class Logo(QWidget):

    _PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "logo.png")

    def __init__(self, height: int = 40, parent=None):
        super().__init__(parent)
        self._src = QPixmap(self._PATH)
        aspect = (self._src.width() / float(self._src.height())) if not self._src.isNull() else 2.0
        self.setFixedSize(int(round(height * aspect)), height)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self._cache = None
        self._cache_dpr = 0.0

    def paintEvent(self, _event):
        if self._src.isNull():
            return
        dpr = self.devicePixelRatioF()
        if self._cache is None or self._cache_dpr != dpr:
            pm = self._src.scaled(round(self.width() * dpr), round(self.height() * dpr),
                                  Qt.AspectRatioMode.IgnoreAspectRatio,
                                  Qt.TransformationMode.SmoothTransformation)
            pm.setDevicePixelRatio(dpr)
            self._cache, self._cache_dpr = pm, dpr
        p = QPainter(self)
        p.drawPixmap(0, 0, self._cache)


class FlowLayout(QLayout):
    def __init__(self, parent=None, hspacing=6, vspacing=6):
        super().__init__(parent)
        self._items = []
        self._h, self._v = hspacing, vspacing
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, index):
        return self._items[index] if 0 <= index < len(self._items) else None

    def takeAt(self, index):
        return self._items.pop(index) if 0 <= index < len(self._items) else None

    def expandingDirections(self):
        return Qt.Orientation(0)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._do_layout(QRect(0, 0, width, 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._do_layout(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QSize()
        for item in self._items:
            size = size.expandedTo(item.minimumSize())
        m = self.contentsMargins()
        return size + QSize(m.left() + m.right(), m.top() + m.bottom())

    def _do_layout(self, rect, test_only):
        m = self.contentsMargins()
        area = rect.adjusted(m.left(), m.top(), -m.right(), -m.bottom())
        x, y, line_h = area.x(), area.y(), 0
        for item in self._items:
            hint = item.sizeHint()
            if x > area.x() and x + hint.width() > area.right() + 1:
                x = area.x()
                y += line_h + self._v
                line_h = 0
            if not test_only:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x += hint.width() + self._h
            line_h = max(line_h, hint.height())
        return y + line_h - rect.y() + m.bottom()


class DropZone(QFrame):
    file_selected = pyqtSignal(str)
    rejected = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("drop-zone")
        self.setAcceptDrops(True)
        self.setMinimumHeight(140)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 14, 20, 14)
        layout.setSpacing(6)

        self._glyph = Glyph("upload", 40)
        self._text = QLabel("Drop a video here, or click to browse")
        self._text.setObjectName("drop-text")
        self._hint = QLabel("MP4, MKV, MOV, AVI, WebM and more")
        self._hint.setObjectName("drop-hint")
        for w in (self._text, self._hint):
            w.setAlignment(Qt.AlignmentFlag.AlignCenter)
            w.setWordWrap(True)
        layout.addStretch(1)
        layout.addWidget(self._glyph, 0, Qt.AlignmentFlag.AlignHCenter)
        layout.addWidget(self._text)
        layout.addWidget(self._hint)
        layout.addStretch(1)
        self._current_path = ""

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._browse()

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            urls = event.mimeData().urls()
            if urls and self._is_video(urls[0].toLocalFile()):
                event.acceptProposedAction()
                self.setProperty("drag-active", True)
                repolish(self)

    def dragLeaveEvent(self, event):
        self.setProperty("drag-active", False)
        repolish(self)

    def dropEvent(self, event):
        self.setProperty("drag-active", False)
        repolish(self)
        urls = event.mimeData().urls()
        if urls:
            path = urls[0].toLocalFile()
            if self._is_video(path) and os.path.isfile(path):
                self.set_path(path, emit=True)
            else:
                self.rejected.emit("That doesn't look like a video file.")

    def _browse(self):
        patterns = " ".join("*%s" % e for e in sorted(VIDEO_EXTENSIONS))
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Video", last_dir(),
            "Video files (%s);;All files (*)" % patterns)
        if path:
            self.set_path(path, emit=True)

    @staticmethod
    def _is_video(path: str) -> bool:
        return os.path.splitext(path)[1].lower() in VIDEO_EXTENSIONS

    def set_path(self, path: str, emit: bool = False):
        self._current_path = path
        remember_dir(path)
        self._glyph.set_kind("film")
        self._text.setText(os.path.basename(path))
        folder = os.path.dirname(path)
        self._hint.setText(folder if len(folder) < 70 else "…" + folder[-67:])
        if emit:
            self.file_selected.emit(path)

    @property
    def current_path(self) -> str:
        return self._current_path


class InfoBar(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("info-bar")
        self._flow = FlowLayout(self, 6, 6)
        self.setLayout(self._flow)
        self.hide()

    def set_info(self, info: dict):
        while self._flow.count():
            item = self._flow.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        from .core import fmt_duration, fmt_size
        v = info.get("video") or {}
        a = info.get("audio") or {}
        parts = []
        if v.get("width") and v.get("height"):
            parts.append("%d×%d" % (v["width"], v["height"]))
        if v.get("codec"):
            parts.append(v["codec"].upper())
        if v.get("fps"):
            parts.append("%s fps" % v["fps"])
        if a.get("codec"):
            parts.append("audio " + a["codec"].upper())
        elif v:
            parts.append("no audio")
        if info.get("duration"):
            parts.append(fmt_duration(info["duration"]))
        if info.get("size"):
            parts.append(fmt_size(info["size"]))
        for text in parts:
            chip = QLabel(text)
            chip.setObjectName("info-chip")
            self._flow.addWidget(chip)
        self.setVisible(bool(parts))
        self.updateGeometry()


class OutputField(QWidget):
    changed = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        self._edit = QLineEdit()
        self._edit.setPlaceholderText("Output path appears here after you choose a video…")
        self._edit.textChanged.connect(self.changed)
        self._edit.textEdited.connect(self._mark_edited)
        self._btn = QPushButton("Browse…")
        self._btn.clicked.connect(self._browse)
        layout.addWidget(self._edit, 1)
        layout.addWidget(self._btn)
        self._user_edited = False

    def _mark_edited(self, _text=""):
        self._user_edited = True

    def _browse(self):
        current = self._edit.text()
        start = current or os.path.join(last_dir(), "output.mp4")
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Output As", start,
            "Video files (*.mp4 *.mkv *.webm *.mov);;"
            "Audio files (*.mp3 *.m4a *.opus *.flac *.wav *.ogg);;All files (*)")
        if path:
            self._edit.setText(path)
            self._user_edited = True

    def set_suggested(self, path: str, force: bool = False):
        if force:
            self._user_edited = False
        if not self._user_edited:
            self._edit.setText(path)

    @property
    def path(self) -> str:
        return self._edit.text().strip()


def section(label: str, *items, spacing: int = 10) -> QWidget:
    card = QWidget()
    card.setObjectName("section")
    card.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
    layout = QVBoxLayout(card)
    layout.setContentsMargins(16, 13, 16, 16)
    layout.setSpacing(spacing)
    title = QLabel(label.upper())
    title.setObjectName("section-label")
    layout.addWidget(title)
    for item in items:
        if isinstance(item, QWidget):
            layout.addWidget(item)
        elif isinstance(item, QLayout):
            layout.addLayout(item)
    return card


def field(label: str, widget: QWidget) -> QVBoxLayout:
    col = QVBoxLayout()
    col.setSpacing(5)
    caption = QLabel(label)
    caption.setObjectName("field-label")
    col.addWidget(caption)
    col.addWidget(widget)
    return col


_LABEL_ROLE = Qt.ItemDataRole.UserRole + 1


def fill_codec_combo(combo, entries, ok_fn):
    for label, value in entries:
        combo.addItem(label, value)
        combo.setItemData(combo.count() - 1, label, _LABEL_ROLE)
    refresh_codec_combo(combo, ok_fn, select_first_available=True)


def refresh_codec_combo(combo, ok_fn, select_first_available=False):
    first_ok = -1
    for index in range(combo.count()):
        label = combo.itemData(index, _LABEL_ROLE)
        available = ok_fn(combo.itemData(index))
        combo.setItemText(index, label if available else label + "  (not installed)")
        combo.model().item(index).setEnabled(available)
        if available and first_ok < 0:
            first_ok = index
    current_ok = combo.currentIndex() >= 0 and combo.model().item(combo.currentIndex()).isEnabled()
    if first_ok >= 0 and (select_first_available or not current_ok):
        combo.setCurrentIndex(first_ok)
