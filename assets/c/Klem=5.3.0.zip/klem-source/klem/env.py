# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from typing import Dict, Optional, Set

_EXTRA_PATHS = [
    "/usr/local/bin", "/usr/bin", "/bin", "/snap/bin",
    os.path.expanduser("~/.local/bin"), "/var/lib/flatpak/exports/bin",
    "/home/linuxbrew/.linuxbrew/bin",
]


class ToolMissing(FileNotFoundError):
    pass


def managed_dir() -> str:
    data_home = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    return os.path.join(data_home, "klem", "bin")


def find_tool(name: str) -> Optional[str]:
    override = os.environ.get("KLEM_" + name.upper())
    if override and os.path.isfile(override) and os.access(override, os.X_OK):
        return override
    own = os.path.join(managed_dir(), name)
    if os.path.isfile(own) and os.access(own, os.X_OK):
        return own
    found = shutil.which(name)
    if found:
        return found
    for directory in _EXTRA_PATHS:
        candidate = os.path.join(directory, name)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _os_release() -> Dict[str, str]:
    data: Dict[str, str] = {}
    try:
        with open("/etc/os-release", encoding="utf-8") as fh:
            for line in fh:
                if "=" in line:
                    key, _, value = line.strip().partition("=")
                    data[key] = value.strip('"')
    except OSError:
        pass
    return data


def install_hint(package: str = "ffmpeg") -> str:
    info = _os_release()
    ids = set((info.get("ID", "") + " " + info.get("ID_LIKE", "")).lower().split())
    if ids & {"debian", "ubuntu", "linuxmint", "pop", "elementary", "zorin", "kali", "raspbian"}:
        return "sudo apt install %s" % package
    if ids & {"fedora", "rhel", "centos", "rocky", "almalinux", "nobara"}:
        return "sudo dnf install %s" % package
    if ids & {"arch", "manjaro", "endeavouros", "garuda", "cachyos"}:
        return "sudo pacman -S %s" % package
    if ids & {"opensuse", "suse", "sles", "opensuse-tumbleweed", "opensuse-leap"}:
        return "sudo zypper install %s" % package
    if "void" in ids:
        return "sudo xbps-install %s" % package
    if "alpine" in ids:
        return "sudo apk add %s" % package
    if ids & {"gentoo"}:
        return "sudo emerge media-video/%s" % package
    return "install '%s' with your package manager" % package


def is_fedora_like() -> bool:
    info = _os_release()
    ids = set((info.get("ID", "") + " " + info.get("ID_LIKE", "")).lower().split())
    return bool(ids & {"fedora", "rhel", "centos", "rocky", "almalinux", "nobara"})


_encoder_cache: Optional[Set[str]] = None


def available_encoders(refresh: bool = False) -> Set[str]:
    global _encoder_cache
    if _encoder_cache is not None and not refresh:
        return _encoder_cache
    names: Set[str] = set()
    ffmpeg = find_tool("ffmpeg")
    if ffmpeg:
        try:
            out = subprocess.run(
                [ffmpeg, "-hide_banner", "-encoders"], stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, timeout=20,
                universal_newlines=True, encoding="utf-8", errors="replace").stdout
            for line in out.splitlines():
                m = re.match(r"^\s*[VAS][\w.]{5}\s+(\S+)", line)
                if m:
                    names.add(m.group(1))
        except (OSError, subprocess.SubprocessError):
            pass
    _encoder_cache = names
    return names


def encoder_ok(name: str) -> bool:
    encoders = available_encoders()
    return (not encoders) or name in encoders or name == "copy"


def open_folder(path: str) -> bool:
    directory = path if os.path.isdir(path) else os.path.dirname(path)
    for opener in ("xdg-open", "gio", "kde-open", "gnome-open"):
        exe = shutil.which(opener)
        if exe:
            argv = [exe, "open", directory] if opener == "gio" else [exe, directory]
            try:
                subprocess.Popen(argv, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
            except OSError:
                continue
    return False


def python_ok() -> bool:
    return sys.version_info >= (3, 8)
