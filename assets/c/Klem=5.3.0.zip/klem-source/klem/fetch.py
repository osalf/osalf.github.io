# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

import hashlib
import os
import platform
import re
import subprocess
import sys
import tarfile
import tempfile
import urllib.request

from . import env

BASE_URL = "https://johnvansickle.com/ffmpeg/releases"
_ARCHIVES = {
    "x86_64": "amd64", "amd64": "amd64",
    "aarch64": "arm64", "arm64": "arm64", "armv8l": "armhf",
    "armv7l": "armhf", "armv6l": "armel",
    "i686": "i686", "i586": "i686", "i386": "i686",
}
_TOOLS = ("ffmpeg", "ffprobe")


class FetchError(RuntimeError):
    pass


def _archive_name() -> str:
    arch = _ARCHIVES.get(platform.machine().lower())
    if not arch:
        raise FetchError("no prebuilt ffmpeg for this CPU (%s)" % platform.machine())
    return "ffmpeg-release-%s-static.tar.xz" % arch


def _md5():
    try:
        return hashlib.md5(usedforsecurity=False)
    except TypeError:
        return hashlib.md5()
    except ValueError as exc:
        raise FetchError("this system has MD5 disabled, so the download can't be checked") from exc


def _open(url: str):
    request = urllib.request.Request(url, headers={"User-Agent": "klem"})
    return urllib.request.urlopen(request, timeout=60)


def _download(url: str, dest: str, say) -> str:
    digest = _md5()
    done, last = 0, -1
    with _open(url) as resp, open(dest, "wb") as out:
        total = int(resp.headers.get("Content-Length") or 0)
        while True:
            chunk = resp.read(1 << 16)
            if not chunk:
                break
            out.write(chunk)
            digest.update(chunk)
            done += len(chunk)
            if total and say:
                pct = done * 100 // total
                if pct // 10 != last // 10:
                    last = pct
                    say("  %d%%" % pct)
    return digest.hexdigest()


def _expected_md5(url: str) -> str:
    with _open(url) as resp:
        text = resp.read(4096).decode("ascii", "replace")
    match = re.search(r"\b[0-9a-fA-F]{32}\b", text)
    if not match:
        raise FetchError("the checksum file could not be read")
    return match.group(0).lower()


def _extract(archive: str, dest_dir: str) -> None:
    found = set()
    with tarfile.open(archive, "r:xz") as tar:
        for member in tar:
            name = os.path.basename(member.name)
            if member.isfile() and name in _TOOLS and name not in found:
                target = os.path.join(dest_dir, name)
                with tar.extractfile(member) as src, open(target, "wb") as out:
                    while True:
                        chunk = src.read(1 << 20)
                        if not chunk:
                            break
                        out.write(chunk)
                os.chmod(target, 0o755)
                found.add(name)
    missing = [t for t in _TOOLS if t not in found]
    if missing:
        raise FetchError("the archive did not contain " + ", ".join(missing))


def _works(path: str) -> bool:
    try:
        subprocess.run([path, "-version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       stdin=subprocess.DEVNULL, timeout=30, check=True)
        return True
    except (OSError, subprocess.SubprocessError):
        return False


def install_ffmpeg(say=print) -> str:
    base = os.environ.get("KLEM_FFMPEG_BASE_URL", BASE_URL).rstrip("/")
    name = _archive_name()
    dest_dir = env.managed_dir()
    os.makedirs(dest_dir, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=dest_dir) as tmp:
        archive = os.path.join(tmp, name)
        unpacked = os.path.join(tmp, "unpacked")
        os.mkdir(unpacked)
        say("Downloading ffmpeg (%s)..." % name)
        try:
            expected = _expected_md5("%s/%s.md5" % (base, name))
            actual = _download("%s/%s" % (base, name), archive, say)
        except OSError as exc:
            raise FetchError("download failed: %s" % exc)
        if actual != expected:
            raise FetchError("the download is corrupted (checksum mismatch); nothing was installed")
        try:
            _extract(archive, unpacked)
        except (tarfile.TarError, EOFError, OSError) as exc:
            raise FetchError("could not unpack the download: %s" % exc)
        for tool in _TOOLS:
            if not _works(os.path.join(unpacked, tool)):
                raise FetchError("the downloaded %s does not run on this system" % tool)
        for tool in _TOOLS:
            os.replace(os.path.join(unpacked, tool), os.path.join(dest_dir, tool))
    env.available_encoders(refresh=True)
    return dest_dir


def main() -> int:
    try:
        folder = install_ffmpeg()
    except FetchError as exc:
        print("Could not install ffmpeg: %s" % exc, file=sys.stderr)
        return 1
    print("ffmpeg and ffprobe installed in %s" % folder)
    return 0


if __name__ == "__main__":
    sys.exit(main())
