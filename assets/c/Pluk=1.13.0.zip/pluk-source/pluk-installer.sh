#!/usr/bin/env bash
# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

set -euo pipefail

PLUK_VERSION="1.13.0"
PLUK_SHA256="80b12facf778c8ad8df9fb67706874a859373f5d2edead8540e884a6cf445d5e"
TMP_DIR=""
BASE_URL="${PLUK_BASE_URL:-https://osaif.pages.dev/pluk-files}"

main() {
    local tarball="pluk-${PLUK_VERSION}.tar.gz"
    local rc=0 sums="" stdin_src

    say()  { printf '\033[1;35m==>\033[0m %s\n' "$*"; }
    die()  { printf '\033[1;31mError:\033[0m %s\n' "$*" >&2; exit 1; }

    [ "$(uname -s)" = "Linux" ] || die "Pluk only runs on Linux."
    [ "$(id -u)" -ne 0 ] || die "Don't run this as root or with sudo."
    for tool in curl tar mktemp; do
        command -v "$tool" >/dev/null 2>&1 || die "'$tool' is required but not installed."
    done

    TMP_DIR="$(mktemp -d)"
    trap '[ -z "$TMP_DIR" ] || rm -rf "$TMP_DIR"' EXIT

    say "Downloading Pluk ${PLUK_VERSION}..."
    curl -fSL --retry 3 --connect-timeout 20 -o "$TMP_DIR/$tarball" \
        "$BASE_URL/$PLUK_VERSION/$tarball" \
        || die "Download failed ($BASE_URL/$PLUK_VERSION/$tarball)."

    if command -v sha256sum >/dev/null 2>&1; then
        sums="$(sha256sum "$TMP_DIR/$tarball")"
    elif command -v shasum >/dev/null 2>&1; then
        sums="$(shasum -a 256 "$TMP_DIR/$tarball")"
    else
        die "'sha256sum' or 'shasum' is required."
    fi
    [ "${sums%% *}" = "$PLUK_SHA256" ] \
        || die "Checksum mismatch."

    tar -xzf "$TMP_DIR/$tarball" -C "$TMP_DIR" || die "Couldn't unpack the download."
    [ -f "$TMP_DIR/pluk-$PLUK_VERSION/install.sh" ] || die "The download doesn't contain the installer."

    if ( : </dev/tty ) 2>/dev/null; then stdin_src=/dev/tty; else stdin_src=/dev/null; fi

    if bash "$TMP_DIR/pluk-$PLUK_VERSION/install.sh" "$@" <"$stdin_src"; then
        rc=0
    else
        rc=$?
    fi
    return "$rc"
}

main "$@"
