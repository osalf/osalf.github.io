# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

import tkinter as tk
from datetime import datetime
from tkinter import font as tkfont, messagebox

from . import capture, db, theme

MAX_SHOWN = 200
PREVIEW_CHARS = 280
PREVIEW_LINES = 5
WRAP_MARGIN = 50
ZOOM_MIN = 0.6
ZOOM_MAX = 3.0
ZOOM_STEP = 0.1
CTRL_MASK = 0x0004

FONT_SPECS = {
    "title":  {"size": 14, "weight": "bold"},
    "back":   {"size": 12, "weight": "bold"},
    "small":  {"size": 9},
    "meta":   {"size": 9, "weight": "bold"},
    "group":  {"size": 10, "weight": "bold"},
    "body":   {"size": 10},
    "link":   {"size": 9, "underline": True},
    "detail": {"size": 11},
}


def _parse(timestamp):
    try:
        return datetime.fromisoformat(timestamp)
    except (ValueError, TypeError):
        return None


def _fmt_time(dt: datetime) -> str:
    return dt.strftime("%I:%M %p").lstrip("0")


def _fmt_date(dt: datetime) -> str:
    return f"{dt:%b} {dt.day}, {dt.year}"


def _day_label(dt: datetime, today) -> str:
    delta = (today - dt.date()).days
    if delta == 0:
        return "Today"
    if delta == 1:
        return "Yesterday"
    return f"{dt:%A}, {dt:%B} {dt.day}, {dt.year}"


def _preview(text: str):
    lines = text.split("\n")
    cut = text
    truncated = False
    if len(lines) > PREVIEW_LINES:
        cut = "\n".join(lines[:PREVIEW_LINES])
        truncated = True
    if len(cut) > PREVIEW_CHARS:
        cut = cut[:PREVIEW_CHARS]
        truncated = True
    if truncated:
        cut = cut.rstrip() + " …"
    return cut, truncated


def _copy_text(root, text: str):
    try:
        capture._copy_to_clipboard(text)
    except RuntimeError:
        root.clipboard_clear()
        root.clipboard_append(text)


def _event_in(root, event) -> bool:
    try:
        return event.widget.winfo_toplevel() is root
    except (AttributeError, KeyError, tk.TclError):
        return False


def build_history_ui(root):
    root.title("Pluk — Clipboard History")
    root.geometry("460x620")
    root.minsize(380, 360)
    root.configure(bg=theme.SURFACE)

    state = {
        "width": 440,
        "search_job": None,
        "zoom": 1.0,
        "view": "list",
        "list_scroll": 0.0,
    }
    wrap_labels = []
    search_var = tk.StringVar()

    fonts = {
        name: tkfont.Font(root=root, family="Sans", **spec) for name, spec in FONT_SPECS.items()
    }

    def set_zoom(value):
        value = round(min(ZOOM_MAX, max(ZOOM_MIN, value)), 2)
        if value == state["zoom"]:
            return
        state["zoom"] = value
        for name, font in fonts.items():
            font.configure(size=max(6, round(FONT_SPECS[name]["size"] * value)))

    header = tk.Frame(root, bg=theme.PRIMARY)
    header.pack(fill="x", side="top")
    title_label = tk.Label(
        header, text="Pluk History", bg=theme.PRIMARY, fg=theme.SURFACE, font=fonts["title"]
    )
    title_label.pack(side="left", padx=16, pady=16)

    back_btn = tk.Button(
        header, text="←  Back", bg=theme.PRIMARY, fg=theme.SURFACE,
        activebackground=theme.PRIMARY_HOVER, activeforeground=theme.SURFACE,
        relief="flat", bd=0, padx=10, cursor="hand2", font=fonts["back"],
    )

    def confirm_clear():
        if not db.get_all():
            return
        if messagebox.askyesno(
            "Clear All",
            "Delete all extracted text from history? This can't be undone.",
            icon="warning",
        ):
            db.clear_all()
            refresh()

    clear_btn = tk.Button(
        header, text="Clear All", bg=theme.DANGER, fg=theme.SURFACE,
        activebackground="#a82a58", activeforeground=theme.SURFACE,
        relief="flat", padx=10, command=confirm_clear, font=fonts["body"],
    )
    clear_btn.pack(side="right", padx=12, pady=10)
    count_label = tk.Label(header, text="", bg=theme.PRIMARY, fg=theme.ACCENT, font=fonts["small"])
    count_label.pack(side="right", padx=(0, 4))

    list_view = tk.Frame(root, bg=theme.SURFACE)
    list_view.pack(fill="both", expand=True, side="top")

    search_bar = tk.Frame(list_view, bg=theme.SURFACE)
    search_bar.pack(fill="x", side="top", padx=12, pady=(10, 4))
    tk.Label(
        search_bar, text="Search", bg=theme.SURFACE, fg=theme.TEXT_SECONDARY, font=fonts["small"]
    ).pack(side="left", padx=(0, 8))
    search_entry = tk.Entry(
        search_bar, textvariable=search_var, relief="flat",
        bg=theme.SURFACE_ALT, fg=theme.TEXT_PRIMARY, insertbackground=theme.TEXT_PRIMARY,
        highlightthickness=1, highlightbackground=theme.BORDER, highlightcolor=theme.PRIMARY,
        font=fonts["body"],
    )
    search_entry.pack(side="left", fill="x", expand=True, ipady=5)
    search_entry.bind("<Escape>", lambda _e: search_var.set(""))

    body = tk.Frame(list_view, bg=theme.SURFACE_ALT)
    body.pack(fill="both", expand=True, side="top")
    canvas = tk.Canvas(body, bg=theme.SURFACE_ALT, highlightthickness=0)
    scrollbar = tk.Scrollbar(body, orient="vertical", command=canvas.yview)
    list_frame = tk.Frame(canvas, bg=theme.SURFACE_ALT)
    window_id = canvas.create_window((0, 0), window=list_frame, anchor="nw", width=state["width"])
    canvas.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)

    def update_scrollregion(_event=None):
        canvas.configure(scrollregion=canvas.bbox("all"))

    def on_canvas_resize(event):
        state["width"] = event.width
        canvas.itemconfigure(window_id, width=event.width)
        wrap = max(event.width - WRAP_MARGIN, 120)
        for label in wrap_labels:
            try:
                label.configure(wraplength=wrap)
            except tk.TclError:
                pass

    list_frame.bind("<Configure>", update_scrollregion)
    canvas.bind("<Configure>", on_canvas_resize)

    detail_view = tk.Frame(root, bg=theme.SURFACE)

    detail_top = tk.Frame(detail_view, bg=theme.SURFACE)
    detail_top.pack(fill="x", side="top", padx=14, pady=(10, 8))
    detail_meta = tk.Label(
        detail_top, text="", bg=theme.SURFACE, fg=theme.TEXT_SECONDARY, font=fonts["meta"]
    )
    detail_meta.pack(side="left")
    detail_buttons = tk.Frame(detail_top, bg=theme.SURFACE)
    detail_buttons.pack(side="right")
    detail_copy = tk.Button(
        detail_buttons, text="Copy", bg=theme.ACCENT, fg=theme.PRIMARY,
        relief="flat", padx=10, font=fonts["body"],
    )
    detail_copy.pack(side="left")
    detail_delete = tk.Button(
        detail_buttons, text="Delete", bg=theme.DANGER, fg=theme.SURFACE,
        activebackground="#a82a58", activeforeground=theme.SURFACE,
        relief="flat", padx=10, font=fonts["body"],
    )
    detail_delete.pack(side="left", padx=(6, 0))

    tk.Frame(detail_view, bg=theme.BORDER, height=1).pack(fill="x", side="top")

    detail_body = tk.Frame(detail_view, bg=theme.SURFACE)
    detail_body.pack(fill="both", expand=True, side="top")
    detail_scroll = tk.Scrollbar(detail_body, orient="vertical")
    detail_text = tk.Text(
        detail_body, wrap="word", bg=theme.SURFACE, fg=theme.TEXT_PRIMARY,
        font=fonts["detail"], relief="flat", bd=0, highlightthickness=0,
        padx=16, pady=12, selectbackground=theme.ACCENT, selectforeground=theme.TEXT_PRIMARY,
        inactiveselectbackground=theme.ACCENT_SOFT, spacing1=1, spacing3=1,
        yscrollcommand=detail_scroll.set, state="disabled",
    )
    detail_scroll.configure(command=detail_text.yview)
    detail_scroll.pack(side="right", fill="y")
    detail_text.pack(side="left", fill="both", expand=True)

    detail_text.bind("<Button-1>", lambda _e: detail_text.focus_set(), add="+")

    def select_all(_event=None):
        detail_text.tag_add("sel", "1.0", "end-1c")
        return "break"

    detail_text.bind("<Control-a>", select_all)
    detail_text.bind("<Control-A>", select_all)

    def on_wheel(event):
        if not _event_in(root, event):
            return
        num = getattr(event, "num", None)
        delta = getattr(event, "delta", 0)
        delta = delta if isinstance(delta, int) else 0
        up = num == 4 or delta > 0
        down = num == 5 or delta < 0
        if not (up or down):
            return
        if int(getattr(event, "state", 0) or 0) & CTRL_MASK:
            set_zoom(state["zoom"] + (ZOOM_STEP if up else -ZOOM_STEP))
            return
        if state["view"] != "list":
            return
        low, high = canvas.yview()
        if low <= 0.0 and high >= 1.0:
            return
        canvas.yview_scroll(-3 if up else 3, "units")

    root.bind_all("<Button-4>", on_wheel, add="+")
    root.bind_all("<Button-5>", on_wheel, add="+")
    root.bind_all("<MouseWheel>", on_wheel, add="+")

    def ctrl_wheel_on_text(event):
        num = getattr(event, "num", None)
        delta = getattr(event, "delta", 0)
        delta = delta if isinstance(delta, int) else 0
        up = num == 4 or delta > 0
        down = num == 5 or delta < 0
        if up or down:
            set_zoom(state["zoom"] + (ZOOM_STEP if up else -ZOOM_STEP))
        return "break"

    for sequence in ("<Control-Button-4>", "<Control-Button-5>", "<Control-MouseWheel>"):
        detail_text.bind(sequence, ctrl_wheel_on_text)

    def zoom_handler(change):
        def handler(event):
            if not _event_in(root, event):
                return None
            set_zoom(1.0 if change is None else state["zoom"] + change)
            return "break"
        return handler

    for sequence in ("<Control-plus>", "<Control-equal>", "<Control-KP_Add>"):
        root.bind_all(sequence, zoom_handler(ZOOM_STEP), add="+")
    for sequence in ("<Control-minus>", "<Control-KP_Subtract>"):
        root.bind_all(sequence, zoom_handler(-ZOOM_STEP), add="+")
    for sequence in ("<Control-0>", "<Control-KP_0>"):
        root.bind_all(sequence, zoom_handler(None), add="+")

    def reset_copy_button(button):
        try:
            button.configure(text="Copy")
        except tk.TclError:
            pass

    def do_copy(button, text):
        _copy_text(root, text)
        button.configure(text="Copied ✓")
        root.after(1200, lambda: reset_copy_button(button))

    def delete_entry(entry_id):
        db.delete_entry(entry_id)
        refresh(keep_scroll=True)

    def show_detail(entry_id, text, dt, created_at):
        if state["view"] == "list":
            state["list_scroll"] = canvas.yview()[0]
        state["view"] = "detail"

        list_view.pack_forget()
        clear_btn.pack_forget()
        count_label.pack_forget()
        title_label.configure(text="Capture")
        back_btn.pack(side="left", padx=(12, 0), before=title_label)
        detail_view.pack(fill="both", expand=True, side="top")

        detail_meta.configure(text=f"{_fmt_time(dt)}  ·  {_fmt_date(dt)}" if dt else str(created_at))
        detail_copy.configure(text="Copy", command=lambda: do_copy(detail_copy, text))
        detail_delete.configure(command=lambda: delete_from_detail(entry_id))

        detail_text.configure(state="normal")
        detail_text.delete("1.0", "end")
        detail_text.insert("1.0", text)
        detail_text.configure(state="disabled")
        detail_text.yview_moveto(0.0)
        detail_text.focus_set()

    def go_back(_event=None):
        if state["view"] != "detail":
            return None
        state["view"] = "list"
        detail_view.pack_forget()
        back_btn.pack_forget()
        title_label.configure(text="Pluk History")
        clear_btn.pack(side="right", padx=12, pady=10)
        count_label.pack(side="right", padx=(0, 4))
        list_view.pack(fill="both", expand=True, side="top")
        root.update_idletasks()
        refresh(scroll_to=state["list_scroll"])
        root.focus_set()
        return "break"

    def delete_from_detail(entry_id):
        db.delete_entry(entry_id)
        go_back()

    back_btn.configure(command=go_back)
    root.bind("<Escape>", go_back, add="+")
    root.bind("<Alt-Left>", go_back, add="+")

    def add_card(entry_id, text, dt, created_at):
        preview, truncated = _preview(text)
        open_it = lambda _e=None, i=entry_id, t=text, d=dt, c=created_at: show_detail(i, t, d, c)

        card = tk.Frame(
            list_frame, bg=theme.SURFACE,
            highlightbackground=theme.BORDER, highlightthickness=1, cursor="hand2",
        )
        card.pack(fill="x", padx=10, pady=4)
        card.bind("<Button-1>", open_it)

        top = tk.Frame(card, bg=theme.SURFACE)
        top.pack(fill="x", padx=10, pady=(8, 0))
        top.bind("<Button-1>", open_it)
        meta = f"{_fmt_time(dt)}  ·  {_fmt_date(dt)}" if dt else str(created_at)
        meta_label = tk.Label(
            top, text=meta, bg=theme.SURFACE, fg=theme.TEXT_SECONDARY, font=fonts["meta"],
        )
        meta_label.pack(side="left")
        meta_label.bind("<Button-1>", open_it)

        buttons = tk.Frame(top, bg=theme.SURFACE)
        buttons.pack(side="right")
        copy_button = tk.Button(
            buttons, text="Copy", bg=theme.ACCENT, fg=theme.PRIMARY,
            relief="flat", padx=10, font=fonts["body"],
        )
        copy_button.configure(command=lambda b=copy_button, t=text: do_copy(b, t))
        copy_button.pack(side="left")
        tk.Button(
            buttons, text="Delete", bg=theme.DANGER, fg=theme.SURFACE,
            activebackground="#a82a58", activeforeground=theme.SURFACE,
            relief="flat", padx=10, font=fonts["body"],
            command=lambda i=entry_id: delete_entry(i),
        ).pack(side="left", padx=(6, 0))

        label = tk.Label(
            card, text=preview, bg=theme.SURFACE, fg=theme.TEXT_PRIMARY, font=fonts["body"],
            anchor="w", justify="left",
            wraplength=max(state["width"] - WRAP_MARGIN, 120), cursor="hand2",
        )
        label.pack(fill="x", padx=10, pady=(4, 4 if truncated else 10))
        label.bind("<Button-1>", open_it)
        wrap_labels.append(label)

        if truncated:
            hint = tk.Label(
                card, text="Open full capture  →", bg=theme.SURFACE, fg=theme.PRIMARY,
                font=fonts["link"], cursor="hand2", anchor="w",
            )
            hint.pack(fill="x", padx=10, pady=(0, 8))
            hint.bind("<Button-1>", open_it)

    def finish_layout(scroll_to):
        list_frame.update_idletasks()
        canvas.configure(scrollregion=canvas.bbox("all"))
        canvas.yview_moveto(scroll_to)

    def refresh(keep_scroll=False, scroll_to=None):
        if scroll_to is None:
            scroll_to = canvas.yview()[0] if keep_scroll else 0.0
        for widget in list_frame.winfo_children():
            widget.destroy()
        wrap_labels.clear()

        all_rows = sorted(
            ((i, t, c, _parse(c)) for i, t, c in db.get_all()),
            key=lambda r: (r[3] or datetime.min, r[0]),
            reverse=True,
        )
        total = len(all_rows)
        query = search_var.get().strip().lower()
        rows = [r for r in all_rows if query in r[1].lower()] if query else all_rows

        if query:
            count_label.configure(text=f"{len(rows)} of {total}")
        else:
            count_label.configure(text=f"{total} capture{'' if total == 1 else 's'}")

        if not rows:
            message = (
                f'No captures match "{search_var.get().strip()}".'
                if query else
                "No extracted text yet.\nUse your shortcut to capture some."
            )
            tk.Label(
                list_frame, text=message, bg=theme.SURFACE_ALT, fg=theme.TEXT_SECONDARY,
                font=fonts["body"], pady=30, justify="center",
            ).pack(fill="x")
            finish_layout(0.0)
            return

        today = datetime.now().date()
        current_group = None
        for entry_id, text, created_at, dt in rows[:MAX_SHOWN]:
            group = _day_label(dt, today) if dt else "Earlier"
            if group != current_group:
                current_group = group
                tk.Label(
                    list_frame, text=group, bg=theme.SURFACE_ALT, fg=theme.PRIMARY,
                    font=fonts["group"], anchor="w",
                ).pack(fill="x", padx=14, pady=(12, 2))
            add_card(entry_id, text, dt, created_at)

        if len(rows) > MAX_SHOWN:
            tk.Label(
                list_frame,
                text=f"Showing the newest {MAX_SHOWN} of {len(rows)}. Use search to find older ones.",
                bg=theme.SURFACE_ALT, fg=theme.TEXT_SECONDARY, font=fonts["small"], pady=12,
            ).pack(fill="x")
        finish_layout(scroll_to)

    def on_search_changed(*_args):
        if state["search_job"] is not None:
            root.after_cancel(state["search_job"])
        state["search_job"] = root.after(150, lambda: refresh())

    search_var.trace_add("write", on_search_changed)

    refresh()
    return refresh
