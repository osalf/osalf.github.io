# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import os
import threading

import pystray
from PIL import Image, ImageDraw

from . import theme
from .notifier import notify

ASSETS_DIR = os.path.join(os.path.dirname(__file__), "assets")
IDLE_ICONS = ("icon_tray.png", "icon_32.png", "icon.png")
ACTIVE_ICONS = ("icon_active.png",)


def _fallback_icon(color: str) -> Image.Image:
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.ellipse((4, 4, 60, 60), fill=color)
    return img


def _load_icon(names, fallback_color: str) -> Image.Image:
    for name in names:
        path = os.path.join(ASSETS_DIR, name)
        if os.path.exists(path):
            img = Image.open(path).convert("RGBA")
            if max(img.size) > 64:
                img = img.resize((64, 64), Image.LANCZOS)
            return img
    return _fallback_icon(fallback_color)


class PlukTray:
    def __init__(self, on_capture, on_open_history, on_open_settings, on_quit, on_check_updates=None):
        self.icon_idle = _load_icon(IDLE_ICONS, theme.PRIMARY)
        self.icon_active = _load_icon(ACTIVE_ICONS, theme.ACCENT)
        self.on_capture = on_capture
        self.on_open_history = on_open_history
        self.on_open_settings = on_open_settings
        self.on_quit_cb = on_quit
        self.on_check_updates_cb = on_check_updates
        menu_items = [
            pystray.MenuItem("Extract Text", self._capture, default=True),
            pystray.MenuItem("Show Pluk", self._open_history),
            pystray.MenuItem("Settings", self._open_settings),
        ]
        if self.on_check_updates_cb:
            menu_items.append(pystray.MenuItem("Check for Updates", self._check_updates))
        menu_items.append(pystray.Menu.SEPARATOR)
        menu_items.append(pystray.MenuItem("Quit", self._quit))
        menu = pystray.Menu(*menu_items)
        self.icon = pystray.Icon("pluk", self.icon_idle, "Pluk", menu)

    @property
    def backend_is_visible(self) -> bool:
        desktop = os.environ.get("XDG_CURRENT_DESKTOP", "").lower()
        if "gnome" not in desktop:
            return True
        return "appindicator" in type(self.icon).__module__

    def set_active(self, active: bool):
        self.icon.icon = self.icon_active if active else self.icon_idle

    def _capture(self, icon=None, item=None):
        threading.Thread(target=self.on_capture, daemon=True).start()

    def _open_history(self, icon=None, item=None):
        self.on_open_history()

    def _open_settings(self, icon=None, item=None):
        self.on_open_settings()

    def _check_updates(self, icon=None, item=None):
        threading.Thread(target=self.on_check_updates_cb, daemon=True).start()

    def _quit(self, icon=None, item=None):
        self.on_quit_cb()
        self.icon.stop()

    def run(self):
        self.icon.run()
