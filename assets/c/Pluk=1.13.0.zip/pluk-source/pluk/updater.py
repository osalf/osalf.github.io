# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import json
import os
import shutil
import tempfile
import urllib.request

from . import __version__


def _parse_version(v: str) -> tuple:
    return tuple(int(p) for p in v.strip().lstrip("v").split("."))


def is_running_as_appimage() -> bool:
    return bool(os.environ.get("APPIMAGE"))


def check_for_update(manifest_url: str, timeout: float = 5.0):
    if not manifest_url:
        return None
    try:
        with urllib.request.urlopen(manifest_url, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None

    remote_version = data.get("version")
    download_url = data.get("url")
    if not remote_version or not download_url:
        return None

    try:
        if _parse_version(remote_version) <= _parse_version(__version__):
            return None
    except ValueError:
        return None

    return {
        "version": remote_version,
        "url": download_url,
        "notes": data.get("notes", ""),
    }


def download_and_replace(download_url: str, timeout: float = 60.0) -> bool:
    appimage_path = os.environ.get("APPIMAGE")
    if not appimage_path or not os.path.exists(appimage_path):
        return False

    target_dir = os.path.dirname(appimage_path)
    fd, tmp_path = tempfile.mkstemp(dir=target_dir, prefix=".pluk_update_")
    os.close(fd)

    try:
        with urllib.request.urlopen(download_url, timeout=timeout) as resp:
            with open(tmp_path, "wb") as out:
                shutil.copyfileobj(resp, out)
        os.chmod(tmp_path, 0o755)
        os.replace(tmp_path, appimage_path)
        return True
    except Exception:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        return False
