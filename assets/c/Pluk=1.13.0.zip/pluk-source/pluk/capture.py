# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import time
import traceback

from . import db, theme
from .logutil import log

MIN_HUMAN_SECONDS = 1.0

TMP_CAPTURE = os.path.join(tempfile.gettempdir(), f"pluk_capture_{os.getpid()}.png")


def _desktop() -> str:
    return os.environ.get("XDG_CURRENT_DESKTOP", "").lower()


def _is_wayland() -> bool:
    session = os.environ.get("XDG_SESSION_TYPE", "").lower()
    if session:
        return session == "wayland"
    return bool(os.environ.get("WAYLAND_DISPLAY"))


def _is_wlroots() -> bool:
    d = _desktop()
    return _is_wayland() and not any(name in d for name in ("gnome", "kde", "plasma"))


def _maim_color(alpha: float) -> str:
    r, g, b = theme.SELECTION_RGB
    return f"{r / 255:.3f},{g / 255:.3f},{b / 255:.3f},{alpha:.2f}"


def _slurp_color(alpha: float) -> str:
    r, g, b = theme.SELECTION_RGB
    return f"#{r:02x}{g:02x}{b:02x}{int(round(alpha * 255)):02x}"


def _have_image() -> bool:
    return os.path.exists(TMP_CAPTURE) and os.path.getsize(TMP_CAPTURE) > 0


def _maim():
    if not shutil.which("maim"):
        return None
    started = time.monotonic()
    result = subprocess.run([
        "maim", "-s", "-l",
        "-c", _maim_color(theme.SELECTION_ALPHA),
        "-b", "2",
        TMP_CAPTURE,
    ], capture_output=True, text=True)
    elapsed = time.monotonic() - started
    log(f"maim exit={result.returncode} after {elapsed:.1f}s stderr={result.stderr.strip()!r}")
    if _have_image():
        return True
    if result.stderr.strip() or elapsed < MIN_HUMAN_SECONDS:
        return None
    return False


def _grim_slurp():
    if not (shutil.which("grim") and shutil.which("slurp")):
        return None
    started = time.monotonic()
    slurp = subprocess.run(
        [
            "slurp",
            "-s", _slurp_color(theme.SELECTION_ALPHA),
            "-c", _slurp_color(theme.SELECTION_BORDER_ALPHA),
            "-b", "00000000",
            "-w", "2",
        ],
        capture_output=True, text=True,
    )
    elapsed = time.monotonic() - started
    log(f"slurp exit={slurp.returncode} after {elapsed:.1f}s stderr={slurp.stderr.strip()!r}")
    geometry = slurp.stdout.strip()
    if not geometry:
        if slurp.stderr.strip() or elapsed < MIN_HUMAN_SECONDS:
            return None
        return False
    grim = subprocess.run(["grim", "-g", geometry, TMP_CAPTURE], capture_output=True, text=True)
    log(f"grim exit={grim.returncode} stderr={grim.stderr.strip()!r}")
    return _have_image() or None


def _gnome_screenshot():
    if not shutil.which("gnome-screenshot"):
        return None
    started = time.monotonic()
    result = subprocess.run(
        ["gnome-screenshot", "-a", "-f", TMP_CAPTURE],
        capture_output=True, text=True,
    )
    elapsed = time.monotonic() - started
    log(f"gnome-screenshot exit={result.returncode} after {elapsed:.1f}s "
        f"stderr={result.stderr.strip()!r}")
    if _have_image():
        return True
    if result.stderr.strip() or elapsed < MIN_HUMAN_SECONDS:
        return None
    return False


def _portal(timeout: int = 120):
    try:
        import gi
        gi.require_version("Gio", "2.0")
        from gi.repository import Gio, GLib
    except Exception as e:
        log(f"portal unavailable (python gi missing?): {e}")
        return None

    ctx = GLib.MainContext.new()
    ctx.push_thread_default()
    try:
        conn = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        sender = conn.get_unique_name().lstrip(":").replace(".", "_")
        token = f"pluk_{os.getpid()}"
        handle = f"/org/freedesktop/portal/desktop/request/{sender}/{token}"
        loop = GLib.MainLoop(ctx)
        result = {}

        def on_response(_conn, _sender, _path, _iface, _signal, params, *_extra):
            code, results = params.unpack()
            result["code"] = code
            result["uri"] = results.get("uri")
            loop.quit()

        sub = conn.signal_subscribe(
            "org.freedesktop.portal.Desktop", "org.freedesktop.portal.Request",
            "Response", handle, None, Gio.DBusSignalFlags.NONE, on_response,
        )
        try:
            conn.call_sync(
                "org.freedesktop.portal.Desktop", "/org/freedesktop/portal/desktop",
                "org.freedesktop.portal.Screenshot", "Screenshot",
                GLib.Variant("(sa{sv})", ("", {
                    "interactive": GLib.Variant("b", True),
                    "handle_token": GLib.Variant("s", token),
                })),
                None, Gio.DBusCallFlags.NONE, -1, None,
            )
            timer = GLib.timeout_source_new_seconds(timeout)
            timer.set_callback(lambda *_: loop.quit() or False)
            timer.attach(ctx)
            loop.run()
        finally:
            conn.signal_unsubscribe(sub)

        code, uri = result.get("code"), result.get("uri")
        log(f"portal response code={code} uri={uri!r}")
        if code is None or code == 1:
            return False
        if code != 0 or not uri:
            return None
        path = GLib.filename_from_uri(uri)[0]
        shutil.copyfile(path, TMP_CAPTURE)
        try:
            os.remove(path)
        except OSError:
            pass
        return _have_image()
    except Exception:
        log("portal error:\n" + traceback.format_exc())
        return None
    finally:
        ctx.pop_thread_default()


def _select_and_screenshot() -> bool:
    if os.path.exists(TMP_CAPTURE):
        os.remove(TMP_CAPTURE)

    if _is_wayland():
        backends = ([_grim_slurp, _gnome_screenshot, _portal] if _is_wlroots()
                    else [_gnome_screenshot, _portal, _grim_slurp])
    else:
        backends = [_maim, _gnome_screenshot]

    for backend in backends:
        outcome = backend()
        name = backend.__name__.lstrip("_")
        log(f"backend {name}: "
            + {True: "got an image", False: "cancelled", None: "not usable, trying next"}[outcome])
        if outcome is not None:
            return outcome

    if _is_wayland():
        raise RuntimeError(
            "No screenshot method worked. Details are in ~/.cache/pluk/pluk.log "
            "(run: pluk --doctor)."
        )
    raise RuntimeError(
        "No screenshot tool found. Install 'maim' (or 'gnome-screenshot') with your package manager."
    )


def _copy_to_clipboard(text: str):
    data = text.encode("utf-8")
    commands = []
    if _is_wayland() and shutil.which("wl-copy"):
        commands.append(["wl-copy"])
    if shutil.which("xclip"):
        commands.append(["xclip", "-selection", "clipboard"])
    if shutil.which("xsel"):
        commands.append(["xsel", "--clipboard", "--input"])
    if not commands:
        raise RuntimeError(
            "No clipboard tool found. Install 'xclip' and 'wl-clipboard' "
            "with your package manager (apt, dnf, pacman or zypper)."
        )
    for cmd in commands:
        try:
            result = subprocess.run(
                cmd, input=data, timeout=5,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        except (subprocess.TimeoutExpired, OSError):
            continue
        if result.returncode == 0:
            return
    raise RuntimeError("Couldn't copy the text to the clipboard.")


def _ocr(image_path: str) -> str:
    if not shutil.which("tesseract"):
        raise RuntimeError(
            "'tesseract' is not installed. Install it with your package manager "
            "(Debian/Ubuntu: tesseract-ocr; Fedora/Arch: tesseract)."
        )
    result = subprocess.run(
        ["tesseract", image_path, "stdout"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"OCR failed: {result.stderr.strip()}")
    return result.stdout.strip()


def capture_and_extract():
    try:
        if not _select_and_screenshot():
            return None
        text = _ocr(TMP_CAPTURE)
        if not text:
            return ""
        _copy_to_clipboard(text)
        db.add_entry(text)
        return text
    finally:
        try:
            os.remove(TMP_CAPTURE)
        except OSError:
            pass
