# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

PRIMARY = "#350247"
PRIMARY_HOVER = "#4A0865"
ACCENT = "#F6C5FD"
ACCENT_SOFT = "#FCE4FF"
SURFACE = "#FFFFFF"
SURFACE_ALT = "#FAF6FB"
TEXT_PRIMARY = "#1A0322"
TEXT_SECONDARY = "#6E5876"
BORDER = "#E8D5EC"
DANGER = "#C4356B"
SUCCESS = "#2E8B57"

SELECTION_RGB = (255, 143, 199)
SELECTION_ALPHA = 0.30
SELECTION_BORDER_ALPHA = 0.90
