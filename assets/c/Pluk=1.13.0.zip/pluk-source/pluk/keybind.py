# Copyright (C) 2021 ocaif
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

import ast
import os
import shlex
import shutil
import subprocess
import sys

SCHEMA = "org.gnome.settings-daemon.plugins.media-keys"
LIST_KEY = "custom-keybindings"
BASE = "/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/pluk/"
ITEM_SCHEMA = f"{SCHEMA}.custom-keybinding:{BASE}"

_MODS = {"<ctrl>": "<Control>", "<alt>": "<Alt>", "<shift>": "<Shift>", "<cmd>": "<Super>"}
_KEYS = {
    "<space>": "space", "<enter>": "Return", "<tab>": "Tab",
    "<backspace>": "BackSpace", "<delete>": "Delete", "<insert>": "Insert",
    "<home>": "Home", "<end>": "End", "<page_up>": "Page_Up",
    "<page_down>": "Page_Down", "<up>": "Up", "<down>": "Down",
    "<left>": "Left", "<right>": "Right",
}


def is_wayland() -> bool:
    return os.environ.get("XDG_SESSION_TYPE", "").lower() == "wayland"


def needs_desktop_binding() -> bool:
    desktop = os.environ.get("XDG_CURRENT_DESKTOP", "").lower()
    return "gnome" in desktop and shutil.which("gsettings") is not None


def to_gnome_accel(shortcut: str) -> str:
    out = []
    for token in shortcut.split("+"):
        token = token.strip().lower()
        if token in _MODS:
            out.append(_MODS[token])
        elif token in _KEYS:
            out.append(_KEYS[token])
        elif token.startswith("<f") and token[2:-1].isdigit():
            out.append(token[1:-1].upper())
        else:
            out.append(token)
    return "".join(out)


def capture_argv() -> list:
    exe = os.path.join(os.path.dirname(sys.executable), "pluk")
    if os.path.exists(exe):
        return [exe, "--capture"]
    return [sys.executable, "-m", "pluk.main", "--capture"]


def capture_command() -> str:
    return " ".join(shlex.quote(a) for a in capture_argv())


def _gs(*args):
    return subprocess.run(["gsettings", *args], capture_output=True, text=True, timeout=10)


def _get_paths() -> list:
    result = _gs("get", SCHEMA, LIST_KEY)
    if result.returncode != 0:
        raise OSError(result.stderr.strip() or "gsettings failed")
    text = result.stdout.strip()
    if text.startswith("@as"):
        text = text[3:].strip()
    return list(ast.literal_eval(text))


def set_gnome_binding(shortcut: str, command: str) -> bool:
    if not shutil.which("gsettings"):
        return False
    try:
        paths = _get_paths()
        if BASE not in paths:
            paths.append(BASE)
            if _gs("set", SCHEMA, LIST_KEY, str(paths)).returncode != 0:
                return False
        for key, value in (("name", "Pluk: extract text"),
                           ("command", command),
                           ("binding", to_gnome_accel(shortcut))):
            if _gs("set", ITEM_SCHEMA, key, value).returncode != 0:
                return False
        return True
    except (OSError, ValueError, SyntaxError, subprocess.SubprocessError):
        return False


def remove_gnome_binding() -> bool:
    if not shutil.which("gsettings"):
        return False
    try:
        paths = _get_paths()
        if BASE in paths:
            paths.remove(BASE)
            _gs("set", SCHEMA, LIST_KEY, str(paths))
        _gs("reset-recursively", ITEM_SCHEMA)
        return True
    except (OSError, ValueError, SyntaxError, subprocess.SubprocessError):
        return False


def get_binding_info():
    if not shutil.which("gsettings"):
        return None
    try:
        if BASE not in _get_paths():
            return None
        info = {}
        for key in ("name", "command", "binding"):
            result = _gs("get", ITEM_SCHEMA, key)
            if result.returncode != 0:
                return None
            info[key] = result.stdout.strip()
        return info
    except (OSError, ValueError, SyntaxError, subprocess.SubprocessError):
        return None


_PRETTY = {"<ctrl>": "Ctrl", "<shift>": "Shift", "<alt>": "Alt", "<cmd>": "Super",
           "<space>": "Space", "<enter>": "Enter", "<tab>": "Tab"}


def pretty_shortcut(shortcut: str) -> str:
    parts = []
    for token in shortcut.split("+"):
        token = token.strip().lower()
        if token in _PRETTY:
            parts.append(_PRETTY[token])
        elif token.startswith("<") and token.endswith(">"):
            parts.append(token[1:-1].replace("_", " ").title().replace("F", "F", 1))
        else:
            parts.append(token.upper())
    return "+".join(parts)
