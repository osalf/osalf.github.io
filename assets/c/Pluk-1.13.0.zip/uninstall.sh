#!/usr/bin/env bash
# Copyright (C) 2021 ocaif
set -euo pipefail
APP_DIR="$HOME/.local/share/pluk"
VENV="$APP_DIR/venv"
PURGE=0
[ "${1:-}" = "--purge" ] && PURGE=1
if [ -x "$VENV/bin/python" ]; then
    "$VENV/bin/python" -c "from pluk import keybind; keybind.remove_gnome_binding()" 2>/dev/null || true
fi
PKILL_PAT="$(printf '%s' "$VENV/bin/pluk" | sed 's/[][\\.*^$+?(){}|\/]/\\&/g')"
pkill -f "$PKILL_PAT" 2>/dev/null || true
if [ "$(readlink /usr/local/bin/pluk 2>/dev/null)" = "$VENV/bin/pluk" ]; then
    sudo rm -f /usr/local/bin/pluk 2>/dev/null || true
fi
rm -f "$HOME/.local/bin/pluk" \
      "$HOME/.local/bin/pluk-uninstall" \
      "$HOME/.local/share/applications/pluk.desktop" \
      "$HOME/.config/autostart/pluk.desktop" \
      "$HOME/Desktop/pluk.desktop"
for size in 32 128 256; do
    rm -f "$HOME/.local/share/icons/hicolor/${size}x${size}/apps/pluk.png"
done
rm -rf "$VENV"
if [ "$PURGE" -eq 1 ]; then
    rm -rf "$APP_DIR" "$HOME/.config/pluk"
    echo "Pluk removed, including its history and settings."
else
    rm -f "$APP_DIR/uninstall.sh"
    echo "Pluk removed. Your history and settings were kept (use --purge to delete them)."
fi
