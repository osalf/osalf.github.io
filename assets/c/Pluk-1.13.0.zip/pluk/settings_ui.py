# Copyright (C) 2021 ocaif
import tkinter as tk
from tkinter import messagebox
from pynput import keyboard as _pynput_keyboard
from . import config, theme
_SHIFT = 0x0001
_CTRL = 0x0004
_ALT = 0x0008
_SUPER = 0x0040
_MODIFIER_KEYSYMS = {
    "Shift_L", "Shift_R", "Control_L", "Control_R", "Alt_L", "Alt_R",
    "Meta_L", "Meta_R", "Super_L", "Super_R", "Hyper_L", "Hyper_R",
    "ISO_Level3_Shift", "ISO_Level5_Shift", "Caps_Lock", "Num_Lock",
    "Scroll_Lock", "Mode_switch",
}
_SPECIAL_KEYS = {
    "space": "<space>", "Return": "<enter>", "KP_Enter": "<enter>",
    "Tab": "<tab>", "ISO_Left_Tab": "<tab>", "BackSpace": "<backspace>",
    "Delete": "<delete>", "Insert": "<insert>", "Home": "<home>",
    "End": "<end>", "Prior": "<page_up>", "Next": "<page_down>",
    "Up": "<up>", "Down": "<down>", "Left": "<left>", "Right": "<right>",
}
_SHIFTED_DIGITS = {
    "exclam": "1", "at": "2", "numbersign": "3", "dollar": "4", "percent": "5",
    "asciicircum": "6", "ampersand": "7", "asterisk": "8", "parenleft": "9",
    "parenright": "0",
}
_PRETTY = {
    "<ctrl>": "Ctrl", "<shift>": "Shift", "<alt>": "Alt", "<cmd>": "Super",
    "<space>": "Space", "<enter>": "Enter", "<tab>": "Tab",
    "<backspace>": "Backspace", "<delete>": "Delete", "<insert>": "Insert",
    "<home>": "Home", "<end>": "End", "<page_up>": "Page Up",
    "<page_down>": "Page Down", "<up>": "Up", "<down>": "Down",
    "<left>": "Left", "<right>": "Right",
}
def pretty_shortcut(shortcut: str) -> str:
    parts = []
    for token in shortcut.split("+"):
        token = token.strip().lower()
        if token in _PRETTY:
            parts.append(_PRETTY[token])
        elif token.startswith("<f") and token[2:-1].isdigit():
            parts.append(token[1:-1].upper())
        else:
            parts.append(token.upper())
    return " + ".join(parts)
def _event_to_shortcut(keysym: str, state: int):
    if keysym in _MODIFIER_KEYSYMS:
        return None, None
    mods = []
    if state & _CTRL:
        mods.append("<ctrl>")
    if state & _ALT:
        mods.append("<alt>")
    if state & _SHIFT:
        mods.append("<shift>")
    if state & _SUPER:
        mods.append("<cmd>")
    if len(keysym) == 1 and keysym.isalpha() and keysym.isascii():
        key = keysym.lower()
    elif len(keysym) == 1 and keysym.isdigit() and keysym.isascii():
        key = keysym
    elif keysym in _SHIFTED_DIGITS:
        key = _SHIFTED_DIGITS[keysym]
    elif keysym in _SPECIAL_KEYS:
        key = _SPECIAL_KEYS[keysym]
    elif keysym.startswith("F") and keysym[1:].isdigit() and 1 <= int(keysym[1:]) <= 20:
        key = f"<{keysym.lower()}>"
    else:
        return None, (
            "That key isn't supported for shortcuts.\n"
            "Use a letter, number, F-key, or a key like Space, Enter or the arrows."
        )
    is_fkey = key.startswith("<f") and key[2:-1].isdigit()
    has_strong_modifier = any(m in mods for m in ("<ctrl>", "<alt>", "<cmd>"))
    if not has_strong_modifier and not is_fkey:
        return None, (
            "Add Ctrl, Alt or Super to your shortcut,\n"
            "otherwise it would trigger while you type."
        )
    return "+".join(mods + [key]), None
def open_settings_window(root, on_save):
    cfg = config.load_config()
    pending = {"shortcut": cfg["shortcut"], "recording": False}
    win = tk.Toplevel(root)
    win.title("Pluk — Settings")
    win.resizable(False, False)
    win.configure(bg=theme.SURFACE)
    tk.Label(
        win, text="Capture Shortcut", bg=theme.SURFACE, fg=theme.PRIMARY,
        font=("Sans", 12, "bold"),
    ).pack(pady=(16, 2))
    tk.Label(
        win,
        text="Click the box, then press the keys you want.",
        bg=theme.SURFACE, fg=theme.TEXT_SECONDARY, font=("Sans", 9),
    ).pack()
    box = tk.Label(
        win, text=pretty_shortcut(pending["shortcut"]),
        bg=theme.SURFACE_ALT, fg=theme.TEXT_PRIMARY,
        font=("Sans", 13, "bold"), relief="flat",
        highlightbackground=theme.BORDER, highlightcolor=theme.PRIMARY,
        highlightthickness=2, takefocus=1, cursor="hand2",
    )
    box.pack(pady=(14, 6), ipady=10, padx=30, fill="x")
    hint = tk.Label(
        win, text="", bg=theme.SURFACE, fg=theme.TEXT_SECONDARY,
        font=("Sans", 9), justify="center", height=2,
    )
    hint.pack()
    def show_idle(message="", color=None):
        pending["recording"] = False
        box.configure(
            text=pretty_shortcut(pending["shortcut"]),
            bg=theme.SURFACE_ALT, fg=theme.TEXT_PRIMARY,
        )
        hint.configure(text=message, fg=color or theme.TEXT_SECONDARY)
    def start_recording(_event=None):
        pending["recording"] = True
        box.configure(text="Press your shortcut…", bg=theme.ACCENT_SOFT, fg=theme.PRIMARY)
        hint.configure(text="Esc to cancel", fg=theme.TEXT_SECONDARY)
        box.focus_force()
    def on_key(event):
        if not pending["recording"]:
            return "break"
        if event.keysym == "Escape":
            show_idle()
            return "break"
        shortcut, error = _event_to_shortcut(event.keysym, event.state)
        if shortcut is None:
            if error:
                show_idle(error, theme.DANGER)
            return "break"
        try:
            _pynput_keyboard.HotKey.parse(shortcut)
        except ValueError:
            show_idle("That combination isn't supported. Try another one.", theme.DANGER)
            return "break"
        pending["shortcut"] = shortcut
        show_idle("Shortcut set. Click Save to apply.", theme.SUCCESS)
        return "break"
    def on_focus_out(_event=None):
        if pending["recording"]:
            show_idle()
    box.bind("<Button-1>", start_recording)
    box.bind("<KeyPress>", on_key)
    box.bind("<FocusOut>", on_focus_out)
    def reset_default():
        pending["shortcut"] = config.DEFAULTS["shortcut"]
        show_idle("Reset to default. Click Save to apply.", theme.SUCCESS)
    def save():
        new_shortcut = pending["shortcut"]
        try:
            _pynput_keyboard.HotKey.parse(new_shortcut)
        except ValueError:
            messagebox.showerror("Pluk", f"'{new_shortcut}' isn't a valid shortcut.", parent=win)
            return
        cfg["shortcut"] = new_shortcut
        config.save_config(cfg)
        on_save(cfg)
        win.destroy()
    buttons = tk.Frame(win, bg=theme.SURFACE)
    buttons.pack(side="bottom", pady=(8, 16))
    tk.Button(
        buttons, text="Reset to default", bg=theme.ACCENT, fg=theme.PRIMARY,
        relief="flat", padx=14, pady=6, command=reset_default,
    ).pack(side="left", padx=6)
    tk.Button(
        buttons, text="Save", bg=theme.PRIMARY, fg=theme.SURFACE, relief="flat",
        activebackground=theme.PRIMARY_HOVER, activeforeground=theme.SURFACE,
        padx=24, pady=6, command=save,
    ).pack(side="left", padx=6)
    win.bind("<Return>", lambda _e: None if pending["recording"] else save())
    win.update_idletasks()
    win.geometry(f"{max(380, win.winfo_reqwidth())}x{win.winfo_reqheight()}")
    win.lift()
    win.focus_force()
    return win
