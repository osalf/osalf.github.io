# Copyright (C) 2021 ocaif
import os
import sqlite3
from datetime import datetime
DATA_DIR = os.path.expanduser("~/.local/share/pluk")
DB_PATH = os.path.join(DATA_DIR, "history.db")
def _connect():
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    return conn
def add_entry(text: str):
    text = text.strip()
    if not text:
        return
    conn = _connect()
    with conn:
        conn.execute(
            "INSERT INTO history (text, created_at) VALUES (?, ?)",
            (text, datetime.now().isoformat(timespec="seconds")),
        )
    conn.close()
def get_all():
    conn = _connect()
    rows = conn.execute(
        "SELECT id, text, created_at FROM history ORDER BY id DESC"
    ).fetchall()
    conn.close()
    return rows
def delete_entry(entry_id: int):
    conn = _connect()
    with conn:
        conn.execute("DELETE FROM history WHERE id = ?", (entry_id,))
    conn.close()
def clear_all():
    conn = _connect()
    with conn:
        conn.execute("DELETE FROM history")
    conn.close()
