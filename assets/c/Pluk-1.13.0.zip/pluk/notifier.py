# Copyright (C) 2021 ocaif
import subprocess
def notify(message: str, title: str = "Pluk"):
    if not message:
        return
    try:
        subprocess.run(["notify-send", title, message], check=False)
    except FileNotFoundError:
        pass
