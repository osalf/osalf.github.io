# Copyright (C) 2021 ocaif
from __future__ import annotations
import argparse
import os
import sys
import time
import traceback
from . import __version__
from .logutil import LOG_PATH, log
_log = log
def _capture_once() -> int:
    from .notifier import notify
    _log("capture started")
    try:
        from . import capture, config
        cfg = config.load_config()
        text = capture.capture_and_extract()
    except RuntimeError as e:
        _log(f"capture error: {e}")
        notify(str(e))
        return 2
    except Exception:
        _log("unexpected error:\n" + traceback.format_exc())
        notify("Pluk hit an unexpected error. Details: ~/.cache/pluk/pluk.log")
        return 2
    if text is None:
        _log("cancelled")
        return 1
    if text == "":
        _log("no text found")
        notify("No text found in the selected area.")
        return 1
    _log(f"copied {len(text)} characters")
    if cfg.get("notify_on_copy", True):
        preview = text if len(text) <= 80 else text[:77] + "..."
        notify(f"Copied to clipboard:\n{preview}")
    return 0
def _register_shortcut() -> int:
    from . import config, keybind
    if not keybind.needs_desktop_binding():
        print("Not GNOME: Pluk registers the shortcut itself when the app runs.")
        return 0
    shortcut = config.load_config()["shortcut"]
    if keybind.set_gnome_binding(shortcut, keybind.capture_command()):
        print(f"Shortcut registered with GNOME: {shortcut}")
        return 0
    print("Couldn't register the shortcut with GNOME.", file=sys.stderr)
    return 1
def _doctor() -> int:
    import shutil
    from . import capture, config, keybind
    ok = True
    print(f"pluk {__version__}")
    print(f"session: {os.environ.get('XDG_SESSION_TYPE', '?')}   "
          f"desktop: {os.environ.get('XDG_CURRENT_DESKTOP', '?')}")
    print(f"shortcut in settings: {config.load_config()['shortcut']}")
    if keybind.needs_desktop_binding():
        info = keybind.get_binding_info()
        if info is None:
            print("GNOME shortcut: NOT REGISTERED   (fix: pluk --register-shortcut)")
            ok = False
        else:
            print(f"GNOME shortcut: {info['binding']} -> {info['command']}")
            exe = keybind.capture_argv()[0]
            if not os.path.exists(exe):
                print(f"  problem: {exe} does not exist")
                ok = False
    desktop = os.environ.get("XDG_CURRENT_DESKTOP", "").lower()
    if (os.environ.get("XDG_SESSION_TYPE", "").lower() == "wayland"
            and "gnome" not in desktop):
        print("note: on this Wayland desktop Pluk can't register a global shortcut itself.")
        print("      Bind the command  pluk --capture  to a key in your desktop's keyboard")
        print("      settings (Sway/Hyprland: add an 'exec pluk --capture' keybinding).")
    print("tools:")
    for tool in ("tesseract", "gnome-screenshot", "maim", "grim", "slurp",
                 "wl-copy", "xclip", "notify-send"):
        print(f"  {tool:17}{'ok' if shutil.which(tool) else 'missing'}")
    if not shutil.which("tesseract"):
        ok = False
    shot = ("gnome-screenshot", "maim", "grim")
    if not any(shutil.which(t) for t in shot):
        print("  problem: no screenshot tool (install gnome-screenshot or maim)")
        ok = False
    if not (shutil.which("xclip") or shutil.which("wl-copy") or shutil.which("xsel")):
        print("  problem: no clipboard tool (install xclip)")
        ok = False
    try:
        with open(LOG_PATH) as f:
            recent = f.read().splitlines()[-12:]
    except OSError:
        recent = []
    try:
        import gi
        print("python gi (screenshot portal support): ok")
    except Exception:
        print("python gi (screenshot portal support): missing")
    print("recent log (shows whether the shortcut ever fired):")
    for line in recent or ["  (empty: no capture has run yet)"]:
        print("  " + line)
    print("RESULT:", "all good" if ok else "something needs fixing (see above)")
    return 0 if ok else 1
def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="pluk",
        description="Select any part of your screen; the text in it is OCR'd to your clipboard.",
    )
    parser.add_argument("--capture", action="store_true",
                        help="select a region, copy its text, and exit")
    parser.add_argument("--register-shortcut", action="store_true",
                        help="register the GNOME keyboard shortcut and exit")
    parser.add_argument("--show-shortcut", action="store_true",
                        help="print the current capture shortcut and exit")
    parser.add_argument("--doctor", action="store_true",
                        help="print a health check and exit")
    parser.add_argument("--background", action="store_true",
                        help="start in the tray without opening the history window")
    parser.add_argument("--version", action="version", version=f"pluk {__version__}")
    args = parser.parse_args(argv)
    if args.capture:
        return _capture_once()
    if args.register_shortcut:
        return _register_shortcut()
    if args.doctor:
        return _doctor()
    if args.show_shortcut:
        from . import config, keybind
        print(keybind.pretty_shortcut(config.load_config()["shortcut"]))
        return 0
    from .app import run_app
    return run_app(background=args.background)
if __name__ == "__main__":
    sys.exit(main())
