# Copyright (C) 2021 ocaif
from __future__ import annotations
import fcntl
import os
import subprocess
import threading
import tkinter as tk
from tkinter import messagebox
from pynput import keyboard
from . import config, history_ui, keybind, settings_ui, updater
from .notifier import notify
from .tray import PlukTray
_lock_file = None
def acquire_single_instance() -> bool:
    global _lock_file
    base = os.environ.get("XDG_RUNTIME_DIR") or os.path.expanduser("~/.cache")
    os.makedirs(base, exist_ok=True)
    _lock_file = open(os.path.join(base, "pluk.lock"), "w")
    try:
        fcntl.flock(_lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        return False
    return True
class PlukApp:
    def __init__(self, background: bool = False):
        self.cfg = config.load_config()
        self.hotkey_listener = None
        self.settings_win = None
        self._quitting = False
        self._capture_lock = threading.Lock()
        self.root = tk.Tk()
        self.refresh_history = history_ui.build_history_ui(self.root)
        self.root.protocol("WM_DELETE_WINDOW", self.hide_window)
        if background:
            self.root.withdraw()
        self.tray = PlukTray(
            on_capture=self.run_capture,
            on_open_history=self.show_window,
            on_open_settings=self.open_settings,
            on_quit=self.quit_app,
            on_check_updates=self.check_for_updates,
        )
        self._resume_hotkey()
        threading.Thread(target=self.tray.run, daemon=True).start()
        if not self.tray.backend_is_visible:
            notify(
                "No tray icon support found. Install the AyatanaAppIndicator library and, on "
                "GNOME, its shell extension (then log out and in). The shortcut still "
                "works. Run 'pluk --doctor' for details."
            )
        if self.cfg.get("auto_check_updates", True) and updater.is_running_as_appimage():
            threading.Thread(target=lambda: self.check_for_updates(silent=True), daemon=True).start()
    def _stop_pynput(self):
        if self.hotkey_listener:
            self.hotkey_listener.stop()
            self.hotkey_listener = None
    def _pause_hotkey(self):
        self._stop_pynput()
        if keybind.needs_desktop_binding():
            keybind.remove_gnome_binding()
    def _resume_hotkey(self):
        shortcut = self.cfg["shortcut"]
        if keybind.needs_desktop_binding():
            if keybind.set_gnome_binding(shortcut, keybind.capture_command()):
                self._stop_pynput()
                return
            if keybind.is_wayland():
                notify("Couldn't register the shortcut with GNOME. "
                       "Use the tray menu instead, or bind 'pluk --capture' to a key.")
                return
        self._stop_pynput()
        try:
            self.hotkey_listener = keyboard.GlobalHotKeys({shortcut: self.run_capture})
            self.hotkey_listener.start()
        except ValueError:
            notify(f"Invalid shortcut '{shortcut}' in config, falling back to default.")
            self.cfg["shortcut"] = config.DEFAULTS["shortcut"]
            config.save_config(self.cfg)
            self.hotkey_listener = keyboard.GlobalHotKeys(
                {self.cfg["shortcut"]: self.run_capture}
            )
            self.hotkey_listener.start()
    def run_capture(self):
        if not self._capture_lock.acquire(blocking=False):
            return
        self.tray.set_active(True)
        try:
            code = subprocess.run(keybind.capture_argv()).returncode
        except OSError as e:
            notify(f"Couldn't start capture: {e}")
            code = 2
        finally:
            self.tray.set_active(False)
            self._capture_lock.release()
        if code == 0:
            self.root.after(0, self.refresh_history)
    def show_window(self):
        self.root.after(0, lambda: (self.root.deiconify(), self.root.lift(),
                                     self.refresh_history()))
    def hide_window(self):
        self.root.withdraw()
    def open_settings(self):
        def on_save(new_cfg):
            self.cfg = new_cfg
        def show():
            if self.settings_win is not None and self.settings_win.winfo_exists():
                self.settings_win.lift()
                self.settings_win.focus_force()
                return
            self._pause_hotkey()
            try:
                win = settings_ui.open_settings_window(self.root, on_save)
            except Exception:
                self._resume_hotkey()
                raise
            self.settings_win = win
            def on_destroy(event):
                if event.widget is win:
                    self.settings_win = None
                    if not self._quitting:
                        self._resume_hotkey()
            win.bind("<Destroy>", on_destroy, add="+")
        self.root.after(0, show)
    def quit_app(self):
        self._quitting = True
        self._stop_pynput()
        if keybind.needs_desktop_binding():
            self._resume_hotkey()
        self.root.after(0, self.root.destroy)
    def check_for_updates(self, silent=False):
        def info_box(text):
            self.root.after(0, lambda: messagebox.showinfo("Pluk", text))
        if not updater.is_running_as_appimage():
            if not silent:
                info_box("Auto-update is only available in the AppImage build.")
            return
        manifest_url = self.cfg.get("update_manifest_url", "")
        if not manifest_url:
            if not silent:
                info_box("Update checking isn't configured for this build.")
            return
        info = updater.check_for_update(manifest_url)
        if not info:
            if not silent:
                info_box("You're already on the latest version.")
            return
        def ask():
            msg = f"A new version ({info['version']}) is available.\n\n"
            if info.get("notes"):
                msg += f"{info['notes']}\n\n"
            msg += "Download and install it now? Pluk will need to be restarted afterward."
            if messagebox.askyesno("Pluk Update Available", msg):
                threading.Thread(target=lambda: self._do_update(info["url"]), daemon=True).start()
        self.root.after(0, ask)
    def _do_update(self, download_url):
        ok = updater.download_and_replace(download_url)
        if ok:
            self.root.after(0, lambda: messagebox.showinfo(
                "Pluk", "Update installed. Please restart Pluk to use the new version."))
        else:
            self.root.after(0, lambda: messagebox.showerror(
                "Pluk", "Update failed. Please try again later."))
    def run(self):
        self.root.mainloop()
def run_app(background: bool = False) -> int:
    if not acquire_single_instance():
        notify("Pluk is already running — look for it in the tray.")
        return 0
    PlukApp(background=background).run()
    return 0
