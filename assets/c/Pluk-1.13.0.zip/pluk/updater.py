# Copyright (C) 2021 ocaif
import json
import os
import shutil
import tempfile
import urllib.request
from . import __version__
def _parse_version(v: str) -> tuple:
    return tuple(int(p) for p in v.strip().lstrip("v").split("."))
def is_running_as_appimage() -> bool:
    return bool(os.environ.get("APPIMAGE"))
def check_for_update(manifest_url: str, timeout: float = 5.0):
    if not manifest_url:
        return None
    try:
        with urllib.request.urlopen(manifest_url, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None
    remote_version = data.get("version")
    download_url = data.get("url")
    if not remote_version or not download_url:
        return None
    try:
        if _parse_version(remote_version) <= _parse_version(__version__):
            return None
    except ValueError:
        return None
    return {
        "version": remote_version,
        "url": download_url,
        "notes": data.get("notes", ""),
    }
def download_and_replace(download_url: str, timeout: float = 60.0) -> bool:
    appimage_path = os.environ.get("APPIMAGE")
    if not appimage_path or not os.path.exists(appimage_path):
        return False
    target_dir = os.path.dirname(appimage_path)
    fd, tmp_path = tempfile.mkstemp(dir=target_dir, prefix=".pluk_update_")
    os.close(fd)
    try:
        with urllib.request.urlopen(download_url, timeout=timeout) as resp:
            with open(tmp_path, "wb") as out:
                shutil.copyfileobj(resp, out)
        os.chmod(tmp_path, 0o755)
        os.replace(tmp_path, appimage_path)
        return True
    except Exception:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        return False
