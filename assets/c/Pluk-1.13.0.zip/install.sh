#!/usr/bin/env bash
# Copyright (C) 2021 ocaif
set -euo pipefail
usage() {
    cat <<'EOF'
Pluk installer

Usage: ./install.sh [options]

Options:
  --no-autostart       don't start Pluk automatically at login
  --desktop-shortcut   also put a Pluk launcher on your Desktop
  --distro NAME        force the package manager instead of auto-detecting.
                       NAME: ubuntu, debian, mint, fedora, arch, opensuse
                       (or apt, dnf, pacman, zypper)
  -h, --help           show this help

Environment (advanced):
  PLUK_SKIP_PACKAGES=1   don't install system packages (you already have them)
                         (PLUK_SKIP_APT=1 still works as an alias)
  PLUK_PIP_ARGS=...      extra arguments for pip
EOF
}
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$HOME/.local/share/pluk"
VENV="$APP_DIR/venv"
BIN_DIR="$HOME/.local/bin"
APPS_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor"
AUTOSTART_DIR="$HOME/.config/autostart"
AUTOSTART=1
DESKTOP_SHORTCUT=0
FORCE_DISTRO="${PLUK_DISTRO:-}"
SKIP_PKGS=0
{ [ "${PLUK_SKIP_PACKAGES:-0}" = "1" ] || [ "${PLUK_SKIP_APT:-0}" = "1" ]; } && SKIP_PKGS=1
while [ "$#" -gt 0 ]; do
    case "$1" in
        --no-autostart) AUTOSTART=0 ;;
        --desktop-shortcut) DESKTOP_SHORTCUT=1 ;;
        --distro)
            [ "$#" -ge 2 ] || { echo "--distro needs a value (try --help)" >&2; exit 1; }
            FORCE_DISTRO="$2"; shift ;;
        --distro=*) FORCE_DISTRO="${1#--distro=}" ;;
        -h|--help) usage; exit 0 ;;
        *) echo "Unknown option: $1 (try --help)" >&2; exit 1 ;;
    esac
    shift
done
say()  { printf '\033[1;35m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33mWarning:\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31mError:\033[0m %s\n' "$*" >&2; exit 1; }
BUILD_DIR=""
PKG_LOG=""
cleanup() {
    [ -z "$BUILD_DIR" ] || rm -rf "$BUILD_DIR"
    [ -z "$PKG_LOG" ] || rm -f "$PKG_LOG"
}
trap cleanup EXIT
[ "$(id -u)" -ne 0 ] || die "Don't run this as root or with sudo — it installs into your home folder (it asks for sudo itself when needed)."
IS_GNOME=0
case "${XDG_CURRENT_DESKTOP:-}" in *GNOME*|*gnome*) IS_GNOME=1 ;; esac
IS_WAYLAND=0
[ "${XDG_SESSION_TYPE:-}" = "wayland" ] && IS_WAYLAND=1
PM=""
pm_from_word() {
    case "$1" in
        debian|ubuntu|linuxmint|mint|pop|zorin|elementary|raspbian|kali|neon|apt) PM=apt ;;
        fedora|rhel|centos|rocky|almalinux|alma|nobara|dnf) PM=dnf ;;
        arch|archlinux|manjaro|endeavouros|garuda|cachyos|artix|pacman) PM=pacman ;;
        suse|sles|sled|opensuse*|zypper) PM=zypper ;;
        *) return 1 ;;
    esac
}
os_field() {
    sed -n "s/^$1=//p" "$2" 2>/dev/null | head -n 1 | tr -d "\"'"
}
detect_pm() {
    local word f="" id="" like=""
    if [ -n "$FORCE_DISTRO" ]; then
        pm_from_word "$(printf '%s' "$FORCE_DISTRO" | tr 'A-Z' 'a-z')" \
            || die "Unknown distro '$FORCE_DISTRO'. Use one of: ubuntu, debian, mint, fedora, arch, opensuse (or apt, dnf, pacman, zypper)."
        return 0
    fi
    if [ -n "${PLUK_OS_RELEASE:-}" ]; then
        f="$PLUK_OS_RELEASE"
    elif [ -r /etc/os-release ]; then
        f=/etc/os-release
    elif [ -r /usr/lib/os-release ]; then
        f=/usr/lib/os-release
    fi
    if [ -n "$f" ] && [ -r "$f" ]; then
        id="$(os_field ID "$f")"
        like="$(os_field ID_LIKE "$f")"
        for word in $id $like; do
            pm_from_word "$word" && return 0
        done
    fi
    if   command -v apt-get >/dev/null 2>&1; then PM=apt
    elif command -v dnf     >/dev/null 2>&1; then PM=dnf
    elif command -v pacman  >/dev/null 2>&1; then PM=pacman
    elif command -v zypper  >/dev/null 2>&1; then PM=zypper
    fi
    [ -n "$PM" ]
}
MANUAL_HELP="Install by hand: python3 (+venv, pip, tkinter), tesseract (+English data), xclip or wl-clipboard, maim (X11) or grim+slurp (Wayland), libnotify, PyGObject + AppIndicator bindings; then re-run with PLUK_SKIP_PACKAGES=1 ./install.sh"
set_packages() {
    case "$PM" in
        apt)
            PM_REQUIRED="python3 python3-venv python3-pip python3-tk tesseract-ocr"
            PM_TOOLS="python3-gi gir1.2-ayatanaappindicator3-0.1 libnotify-bin xclip maim wl-clipboard"
            PM_PYLIBS="python3-pil python3-pynput python3-pystray python3-xlib python3-evdev"
            PM_BUILD="build-essential python3-dev" ;;
        dnf)
            PM_REQUIRED="python3 python3-pip python3-tkinter tesseract"
            PM_TOOLS="tesseract-langpack-eng python3-gobject libayatana-appindicator-gtk3 libnotify xclip maim wl-clipboard"
            PM_PYLIBS="python3-pillow python3-pynput python3-pystray python3-xlib python3-evdev"
            PM_BUILD="gcc python3-devel" ;;
        pacman)
            PM_REQUIRED="python python-pip tk tesseract"
            PM_TOOLS="tesseract-data-eng python-gobject libayatana-appindicator libnotify xclip maim wl-clipboard"
            PM_PYLIBS="python-pillow python-pynput python-xlib python-evdev"
            PM_BUILD="base-devel" ;;
        zypper)
            PM_REQUIRED="python3 python3-pip python3-tk tesseract-ocr"
            PM_TOOLS="tesseract-ocr-traineddata-english python3-gobject typelib-1_0-AyatanaAppIndicator3-0_1 libnotify-tools xclip maim wl-clipboard"
            PM_PYLIBS="python3-Pillow python3-pynput python3-python-xlib python3-evdev"
            PM_BUILD="gcc python3-devel" ;;
    esac
    PM_GNOME="gnome-screenshot gnome-shell-extension-appindicator"
    PM_WLROOTS="grim slurp"
}
pm_install() {
    case "$PM" in
        apt)    sudo apt-get install -y "$@" ;;
        dnf)    sudo dnf install -y "$@" ;;
        pacman) sudo pacman -S --needed --noconfirm "$@" ;;
        zypper) sudo zypper --non-interactive install "$@" ;;
    esac
}
try_group() {
    local mode="$1" pkg
    shift
    [ "$SKIP_PKGS" -eq 0 ] || return 0
    [ "$#" -gt 0 ] || return 0
    if pm_install "$@" >"$PKG_LOG" 2>&1 </dev/null; then
        echo "  + $*"
        return 0
    fi
    for pkg in "$@"; do
        if pm_install "$pkg" >"$PKG_LOG" 2>&1 </dev/null; then
            echo "  + $pkg"
        elif [ "$mode" = quiet ]; then
            echo "  - $pkg isn't in this distro's repositories (pip will fetch it if needed)"
        else
            warn "couldn't install optional package: $pkg (skipping)"
        fi
    done
    return 0
}
install_system_packages() {
    detect_pm || die "Couldn't tell which Linux distribution this is. Re-run with --distro ubuntu|debian|mint|fedora|arch|opensuse. $MANUAL_HELP"
    command -v "$( [ "$PM" = apt ] && echo apt-get || echo "$PM" )" >/dev/null 2>&1 \
        || die "Detected the '$PM' family, but its package manager isn't available here (immutable/atomic distro?). $MANUAL_HELP"
    command -v sudo >/dev/null 2>&1 \
        || die "'sudo' is required to install system packages. Install sudo, or install the packages yourself and re-run with PLUK_SKIP_PACKAGES=1. $MANUAL_HELP"
    set_packages
    say "Detected package manager: $PM. Installing system packages (you may be asked for your password)..."
    case "$PM" in
        apt)    sudo apt-get update || warn "'apt update' reported errors (often a broken third-party repository). Continuing anyway." ;;
        zypper) sudo zypper --non-interactive refresh || warn "'zypper refresh' reported errors. Continuing anyway." ;;
    esac
    local hint=""
    [ "$PM" != pacman ] || hint=" If it says a file could not be retrieved (404), run 'sudo pacman -Syu' once and re-run the installer."
    pm_install $PM_REQUIRED \
        || die "Couldn't install the required system packages ($PM_REQUIRED). Fix the error above and re-run ./install.sh.$hint"
    say "Installing helper tools..."
    try_group loud $PM_TOOLS
    try_group quiet $PM_PYLIBS
    if [ "$IS_GNOME" -eq 1 ]; then
        try_group loud $PM_GNOME
    elif [ "$IS_WAYLAND" -eq 1 ]; then
        try_group loud $PM_WLROOTS
    fi
}
PKG_LOG="$(mktemp)"
if [ "$SKIP_PKGS" -eq 1 ]; then
    say "Skipping system packages (PLUK_SKIP_PACKAGES=1)."
    PM_BUILD=""
else
    install_system_packages
fi
command -v python3 >/dev/null 2>&1 || die "python3 not found. $MANUAL_HELP"
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' \
    || die "Pluk needs Python 3.8 or newer, but this system has: $(python3 --version 2>&1)."
python3 -c 'import tkinter' >/dev/null 2>&1 \
    || die "Python's Tk support (tkinter) is missing, and Pluk's window needs it. Install it (Debian/Ubuntu: python3-tk, Fedora: python3-tkinter, Arch: tk, openSUSE: python3-tk) and re-run."
command -v tesseract >/dev/null 2>&1 \
    || die "'tesseract' (the OCR engine) is not installed. Install it (Debian/Ubuntu/openSUSE: tesseract-ocr, Fedora/Arch: tesseract) and re-run."
TESS_LANGS="$(tesseract --list-langs 2>&1 || true)"
case $'\n'"$TESS_LANGS"$'\n' in
    *$'\n'eng$'\n'*) ;;
    *) warn "Tesseract's English data wasn't found, so OCR may fail. Install it (Debian/Ubuntu: tesseract-ocr-eng, Fedora: tesseract-langpack-eng, Arch: tesseract-data-eng, openSUSE: tesseract-ocr-traineddata-english)." ;;
esac
say "Setting up Pluk in $APP_DIR ..."
mkdir -p "$APP_DIR" "$BIN_DIR" "$APPS_DIR"
PKILL_PAT="$(printf '%s' "$VENV/bin/pluk" | sed 's/[][\\.*^$+?(){}|\/]/\\&/g')"
pkill -f "$PKILL_PAT" 2>/dev/null || true
sleep 1
rm -rf "$VENV"
python3 -m venv --system-site-packages "$VENV" \
    || die "Couldn't create a Python environment. Is the 'venv' module installed (Debian/Ubuntu: python3-venv)?"
BUILD_DIR="$(mktemp -d)"
cp -r "$SRC_DIR/." "$BUILD_DIR/"
rm -rf "$BUILD_DIR/venv" "$BUILD_DIR/.git" "$BUILD_DIR/build" "$BUILD_DIR/dist" "$BUILD_DIR/tools"
PIP_EXTRA=(${PLUK_PIP_ARGS:-})
pip_install() { "$VENV/bin/pip" install ${PIP_EXTRA[@]+"${PIP_EXTRA[@]}"} "$BUILD_DIR"; }
if ! pip_install; then
    warn "pip failed — installing build tools and retrying once."
    try_group loud ${PM_BUILD:-}
    pip_install || die "Couldn't install Pluk's Python packages. See the pip error above."
fi
[ -x "$VENV/bin/pluk" ] || die "Install finished but the 'pluk' command is missing."
install -Dm755 "$SRC_DIR/uninstall.sh" "$APP_DIR/uninstall.sh"
ln -sf "$APP_DIR/uninstall.sh" "$BIN_DIR/pluk-uninstall"
ln -sf "$VENV/bin/pluk" "$BIN_DIR/pluk"
PLUK_ON_PATH=0
if command -v sudo >/dev/null 2>&1 && sudo -n ln -sf "$VENV/bin/pluk" /usr/local/bin/pluk 2>/dev/null </dev/null; then
    PLUK_ON_PATH=1
fi
for size in 32 128 256; do
    install -Dm644 "$SRC_DIR/pluk/assets/icon_${size}.png" "$ICON_DIR/${size}x${size}/apps/pluk.png"
done
gtk-update-icon-cache -q -f -t "$ICON_DIR" 2>/dev/null || true
make_desktop() {
    local exec_line="$1"
    exec_line="${exec_line//%/%%}"
    exec_line="${exec_line//\\/\\\\}"
    exec_line="${exec_line//&/\\&}"
    exec_line="${exec_line//|/\\|}"
    sed "s|__EXEC__|$exec_line|g" "$SRC_DIR/pluk.desktop.template" > "$2"
    chmod +x "$2"
}
make_desktop "\"$BIN_DIR/pluk\"" "$APPS_DIR/pluk.desktop"
update-desktop-database "$APPS_DIR" 2>/dev/null || true
if [ "$AUTOSTART" -eq 1 ]; then
    mkdir -p "$AUTOSTART_DIR"
    make_desktop "\"$BIN_DIR/pluk\" --background" "$AUTOSTART_DIR/pluk.desktop"
    echo "X-GNOME-Autostart-enabled=true" >> "$AUTOSTART_DIR/pluk.desktop"
fi
if [ "$DESKTOP_SHORTCUT" -eq 1 ] && [ -d "$HOME/Desktop" ]; then
    make_desktop "\"$BIN_DIR/pluk\"" "$HOME/Desktop/pluk.desktop"
    gio set "$HOME/Desktop/pluk.desktop" "metadata::trusted" true 2>/dev/null || true
fi
if [ "$IS_GNOME" -eq 1 ] && command -v gnome-extensions >/dev/null 2>&1; then
    EXT_LIST="$(gnome-extensions list 2>/dev/null || true)"
    for ext in ubuntu-appindicators@ubuntu.com appindicatorsupport@rgcjonas.gmail.com; do
        case $'\n'"$EXT_LIST"$'\n' in
            *$'\n'"$ext"$'\n'*)
                gnome-extensions enable "$ext" 2>/dev/null || true
                break ;;
        esac
    done
fi
if ! "$VENV/bin/pluk" --register-shortcut; then
    warn "couldn't register the keyboard shortcut. Run: pluk --doctor"
fi
if [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then
    say "Starting Pluk..."
    nohup "$BIN_DIR/pluk" --background >/dev/null 2>&1 &
    disown 2>/dev/null || true
fi
echo
say "Health check:"
"$VENV/bin/pluk" --doctor || warn "the check above found a problem. Fix what it lists (usually a missing package), then run: pluk --doctor"
echo
say "Pluk is installed."
SHORTCUT_TEXT="$("$VENV/bin/pluk" --show-shortcut 2>/dev/null || echo "your shortcut")"
if [ "$IS_WAYLAND" -eq 1 ] && [ "$IS_GNOME" -eq 0 ]; then
    echo "  Capture text:  bind the command  pluk --capture  to a key in your desktop's keyboard"
    echo "                 settings (Sway/Hyprland: add 'bindsym <keys> exec pluk --capture'),"
    echo "                 or use the tray icon. Then drag over some text and paste anywhere."
else
    echo "  Capture text:  press $SHORTCUT_TEXT, drag over some text, paste anywhere."
fi
echo "  Open the app:  search for \"Pluk\" in your applications menu, or run: pluk"
echo "  Change the shortcut: tray icon -> Settings."
echo "  Something wrong?  Run: pluk --doctor      (log file: ~/.cache/pluk/pluk.log)"
echo "  Remove Pluk:   pluk-uninstall             (add --purge to delete history too)"
case ":$PATH:" in
    *":$BIN_DIR:"*) ;;
    *) [ "$PLUK_ON_PATH" -eq 1 ] || echo "  Note: until you log out and back in, run Pluk with: $VENV/bin/pluk   (and Remove with: $APP_DIR/uninstall.sh)" ;;
esac
if [ "$IS_GNOME" -eq 1 ]; then
    echo "  GNOME: if you don't see the tray icon, log out and back in once."
fi
