# Copyright (C) 2021 ocaif
import re
from pathlib import Path
from setuptools import setup, find_packages
version = re.search(
    r'__version__ = "([^"]+)"', Path("pluk/__init__.py").read_text()
).group(1)
setup(
    name="pluk",
    version=version,
    description="Select any part of your screen, and the text in it gets OCR'd straight to your clipboard.",
    author="ocaif",
    packages=find_packages(),
    package_data={"pluk": ["assets/*.png"]},
    install_requires=[
        "Pillow>=10.0.0",
        "pystray>=0.19.5",
        "pynput>=1.7.6",
    ],
    entry_points={
        "gui_scripts": ["pluk=pluk.main:main"],
    },
    license="GPL-3.0-or-later",
    classifiers=[
        "License :: OSI Approved :: GNU General Public License v3 or later (GPLv3+)",
        "Programming Language :: Python :: 3",
        "Operating System :: POSIX :: Linux",
    ],
    python_requires=">=3.8",
)
